-- ---------------------------------------------------------------------------
-- Tallypoint Systems warehouse inventory (Task 2, VM 2: vm1-warehouse-db)
--
-- Run on the warehouse server:   sudo mysql warehouse < tallypoint-warehouse.sql
-- Safe to run more than once: columns are added only if missing, and items are
-- matched by SKU, so a second run updates rows instead of duplicating them.
-- ---------------------------------------------------------------------------

-- 1. Columns a real warehouse needs (added only if missing)
ALTER TABLE inventory
  ADD COLUMN IF NOT EXISTS sku VARCHAR(20) AFTER item_id,
  ADD COLUMN IF NOT EXISTS category ENUM('Raw material','Finished good','Supply')
      NOT NULL DEFAULT 'Finished good' AFTER item_name,
  ADD COLUMN IF NOT EXISTS unit VARCHAR(10) NOT NULL DEFAULT 'each' AFTER quantity,
  ADD COLUMN IF NOT EXISTS reorder_level INT NOT NULL DEFAULT 0 AFTER unit,
  ADD COLUMN IF NOT EXISTS supplier VARCHAR(60) AFTER location,
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP
      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

ALTER TABLE inventory ADD UNIQUE INDEX IF NOT EXISTS uq_inventory_sku (sku);

-- 2. Audit log: each physical count of an item
CREATE TABLE IF NOT EXISTS inventory_audit (
  audit_id    INT AUTO_INCREMENT PRIMARY KEY,
  item_id     INT NOT NULL,
  counted_qty INT NOT NULL,
  audited_by  VARCHAR(50) NOT NULL,
  audited_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  notes       VARCHAR(255),
  FOREIGN KEY (item_id) REFERENCES inventory(item_id)
);

-- 3. Remove earlier placeholder rows (Task 1 widgets and the guide's old sample items)
DELETE a FROM inventory_audit a
  JOIN inventory i ON i.item_id = a.item_id
 WHERE i.item_name IN ('Widget A', 'Widget B', 'Gadget C')
    OR i.sku IN ('FG-MUG-01','FG-CDL-01','FG-TOT-01','FG-BTL-01','FG-ORG-01',
                 'RM-CLY-01','RM-WAX-01','RM-CNV-01','SP-BOX-01','SP-TPE-01');
DELETE FROM inventory
 WHERE item_name IN ('Widget A', 'Widget B', 'Gadget C')
    OR sku IN ('FG-MUG-01','FG-CDL-01','FG-TOT-01','FG-BTL-01','FG-ORG-01',
               'RM-CLY-01','RM-WAX-01','RM-CNV-01','SP-BOX-01','SP-TPE-01');

-- 4. Tallypoint inventory
--    Raw materials: components received from hardware and software vendors
--    Finished goods: terminals imaged and bundles assembled by the fulfillment team
--    Supplies: packaging and shipping materials
INSERT INTO inventory
  (sku, item_name, category, quantity, unit, reorder_level, location, supplier)
VALUES
  ('RM-TRM-15',  '15-inch touchscreen terminal (unimaged)', 'Raw material',   64, 'each',     20, 'Receiving Bay A',  'Elo Touch'),
  ('RM-PRN-80',  '80 mm thermal receipt printer',           'Raw material',   85, 'each',     25, 'Bay A, Rack 2',    'Star Micronics'),
  ('RM-SCN-2D',  '2D barcode scanner with stand',           'Raw material',  110, 'each',     30, 'Bay B, Rack 1',    'Honeywell'),
  ('RM-DRW-HD',  'Heavy-duty cash drawer',                  'Raw material',   48, 'each',     20, 'Bay B, Floor',     'APG'),
  ('RM-CRD-EMV', 'EMV and contactless card reader',         'Raw material',   15, 'each',     25, 'Secure cage',      'Verifone'),
  ('RM-LIC-IOT', 'Windows IoT Enterprise license',          'Raw material',  140, 'licenses', 50, 'License vault',    'Microsoft'),
  ('TP-HW-TRM',  'Imaged 15-inch terminal, Tallypoint POS', 'Finished good',  30, 'each',     10, 'Staging, Rack 3',  'Tallypoint fulfillment'),
  ('TP-BND-CMP', 'Complete POS Bundle, boxed',              'Finished good',  22, 'each',     10, 'Outbound dock',    'Tallypoint fulfillment'),
  ('SP-BOX-BND', 'Bundle shipping carton',                  'Supply',        200, 'each',     60, 'Packaging aisle',  'Packaging supplier'),
  ('SP-FOAM-IN', 'Foam insert set for bundle carton',       'Supply',        180, 'sets',     60, 'Packaging aisle',  'Packaging supplier'),
  ('SP-PPR-80',  '80 mm thermal paper roll',                'Supply',        400, 'rolls',   150, 'Bay A, Rack 4',    'Office supply vendor'),
  ('SP-LBL-SHP', 'Carrier shipping labels',                 'Supply',       1500, 'labels',  500, 'Outbound dock',    'UPS / FedEx')
ON DUPLICATE KEY UPDATE
  item_name = VALUES(item_name), category = VALUES(category), quantity = VALUES(quantity),
  unit = VALUES(unit), reorder_level = VALUES(reorder_level),
  location = VALUES(location), supplier = VALUES(supplier);

-- 5. Show the result
SELECT sku, item_name, category, quantity, unit, supplier
  FROM inventory ORDER BY FIELD(category, 'Raw material', 'Finished good', 'Supply'), sku;

SELECT sku, item_name, quantity, reorder_level AS reorder_at
  FROM inventory WHERE quantity <= reorder_level;
