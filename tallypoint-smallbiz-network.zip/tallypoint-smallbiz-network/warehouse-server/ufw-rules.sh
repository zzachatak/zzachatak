#!/usr/bin/env bash
# Host firewall for the warehouse server. Run in this order:
# allowing SSH before enabling ufw prevents locking yourself out.
set -euo pipefail
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow from 35.235.240.0/20 to any port 22 proto tcp   # SSH via IAP
sudo ufw allow from 35.235.240.0/20 to any port 80 proto tcp   # phpMyAdmin via IAP tunnel
sudo ufw --force enable
sudo ufw status verbose
