-- Read-only auditor account for the warehouse database.
-- Replace the placeholder password before running:
--   sudo mysql < create-auditor.sql
CREATE USER IF NOT EXISTS 'warehouse_auditor'@'localhost' IDENTIFIED BY 'CHANGE-ME-strong-password';
GRANT SELECT ON warehouse.* TO 'warehouse_auditor'@'localhost';
GRANT INSERT ON warehouse.inventory_audit TO 'warehouse_auditor'@'localhost';
FLUSH PRIVILEGES;
