#!/usr/bin/env bash
# Task 1 email test on vm3-mail (Postfix in "Local only" mode, mail name smallbiz.local).
# Prerequisite: sudo apt install -y postfix mailutils ; sudo adduser alice ; sudo adduser bob
set -euo pipefail
sudo postfix status
echo "Hello Bob, this is a Task 1 test from Alice." | sudo -u alice mail -s "Task 1 test email" bob
sleep 2
sudo journalctl --no-pager -n 30 | grep postfix | grep -E "to=<bob@" || true
echo "Read it with: sudo -u bob mail"
