# Task 2 – E-Commerce & Warehouse Inventory Guide

> The scripts and SQL referenced here live in this repository: [`web-server/store-setup`](../web-server/store-setup) and [`warehouse-server`](../warehouse-server).

## 1. Overview

Task 2 turns the Task 1 web server into a public WordPress + WooCommerce store and turns the Task 1 database server into a private warehouse inventory system with a phpMyAdmin portal. The store is reachable from the internet on web ports only; the warehouse remains completely private.

The business is **Tallypoint Systems**, a 136-person company that sells Windows point-of-sale software and hardware to independent retailers and small chains. The store sells Tallypoint's POS software licenses, checkout hardware and installation service; the warehouse tracks the vendor components, imaged terminals and bundles its fulfillment team assembles.

This guide is written as a hand-off to an incoming IT team: every step lists the command, what it does, and why it was chosen. It assumes the Task 1 build (private VPC `smallbiz-vpc`, region `us-west1`, zone `us-west1-b`) is in place.

### Role mapping

The assignment numbers the servers differently from the Task 1 names. The existing servers were kept and upgraded rather than rebuilt, so their names stay the same.

| Task 2 role | Server name | Task 1 state | Task 2 state |
| --- | --- | --- | --- |
| VM 1: Customer-facing e-commerce server | `vm2-web` | Private LAMP + phpMyAdmin | Static public IP, WordPress + WooCommerce store, 5+ products, accounts, checkout |
| VM 2: Warehouse inventory system | `vm1-warehouse-db` | Private MariaDB with `warehouse` database | Still private; 5+ inventory items, phpMyAdmin portal reached only through IAP |
| Not used in Task 2 | `vm3-mail` | Postfix | Stopped to save credit; returns in later tasks |

### End state

- Customers browse `http://<static-ip>`, create an account, log in and complete a checkout.
- Warehouse staff open phpMyAdmin through an IAP tunnel, log in as an administrator and audit inventory.
- Neither database port (3306) is reachable from the internet, and the two servers do not depend on each other.

**Before starting:** start both servers (`gcloud compute instances start vm1-warehouse-db vm2-web --zone=us-west1-b`) and patch them with `sudo apt update && sudo apt upgrade -y`.

## 2. Network changes

The store server gets a reserved static public IP and a firewall rule that opens only ports 80 and 443 to the internet. Two deny rules wall the store off from the warehouse, and SSH to both servers still goes only through IAP.

```mermaid
flowchart TB
  cust["Customers<br/>any address"] -- "80 / 443 (allow-web)" --> web
  admin["Administrator<br/>Cloud Shell via IAP"] -- "IAP: SSH 22" --> web
  admin -- "IAP: SSH 22 + tunnel 80" --> wh
  subgraph vpc["smallbiz-vpc · 10.10.0.0/24 · us-west1"]
    web["vm2-web · VM 1 e-commerce<br/>static public IP · WordPress + WooCommerce<br/>tag: web-server"]
    wh["vm1-warehouse-db · VM 2 inventory<br/>internal IP only · MariaDB + phpMyAdmin<br/>tag: warehouse"]
  end
  web x--x wh
```

*Task 2 network: public web tier, private warehouse, and no path between them.*

`vm2-web` is the only server with a public address. The crossed link is the path the deny rules remove: even if the store were compromised, it could not reach the warehouse.

### Why these changes

| Change | Why |
| --- | --- |
| Static (reserved) external IP on `vm2-web` | WordPress saves its own address into its settings and into every image link. A normal ephemeral IP can change when the server restarts, which breaks the site and its images. A reserved IP never changes. |
| `allow-web` rule: TCP 80, 443 from 0.0.0.0/0 | Customers can come from any address, so the web ports must be open to everyone. 443 is for HTTPS (section 6). |
| Rule targets the `web-server` tag | Network tags let a rule apply to chosen servers only. Only `vm2-web` carries the tag, so the warehouse never gets these open ports. |
| No change to SSH | Port 22 stays limited to IAP's range (35.235.240.0/20). Opening SSH to the internet would invite constant password-guessing attacks. |
| Deny rules between `web-server` and `warehouse` | The Task 1 `allow-internal` rule lets every server talk to every other one. The assignment asks for strict separation, so higher-priority deny rules override it for these two servers in both directions. |

### Step 1: Reserve a static IP and attach it to vm2-web

In Task 1, `vm2-web` was created with no external IP, so there is no ephemeral address to promote. Reserving a new static address and attaching it gives the same result.

```bash
# Reserve a regional static IP named store-ip
gcloud compute addresses create store-ip --region=us-west1

# Save the reserved address in a variable and print it
IP=$(gcloud compute addresses describe store-ip --region=us-west1 --format='value(address)')
echo $IP

# Attach it to vm2-web
gcloud compute instances add-access-config vm2-web \
  --zone=us-west1-b --access-config-name=external-nat --address=$IP
```

- `addresses create` reserves an IP that stays yours until you release it.
- `--format='value(address)'` prints only the IP itself, which the `$( )` stores in `IP`.
- `add-access-config` gives the server's network card a public address, mapped to its existing internal IP.
- **Record the IP.** This guide calls it `<static-ip>` from here on.

Console alternative: **VPC network → IP addresses → Reserve external static IP address**, choosing region `us-west1` and attaching to `vm2-web`.

**Cost note:** a reserved IP is billed while it exists, and it costs more while it is not attached to a running server. If you delete the store later, release the IP too: `gcloud compute addresses delete store-ip --region=us-west1`.

### Step 2: Open web ports to the store only

```bash
# Allow HTTP and HTTPS from anywhere, only to servers tagged web-server
gcloud compute firewall-rules create allow-web \
  --network=smallbiz-vpc --direction=INGRESS --action=ALLOW \
  --rules=tcp:80,tcp:443 --source-ranges=0.0.0.0/0 --target-tags=web-server

# Tag the servers
gcloud compute instances add-tags vm2-web --zone=us-west1-b --tags=web-server
gcloud compute instances add-tags vm1-warehouse-db --zone=us-west1-b --tags=warehouse
```

### Step 3: Separate the store from the warehouse

```bash
# Store -> warehouse: blocked
gcloud compute firewall-rules create deny-web-to-warehouse \
  --network=smallbiz-vpc --direction=INGRESS --action=DENY --rules=all \
  --source-tags=web-server --target-tags=warehouse --priority=900

# Warehouse -> store (internal network): blocked
gcloud compute firewall-rules create deny-warehouse-to-web \
  --network=smallbiz-vpc --direction=INGRESS --action=DENY --rules=all \
  --source-tags=warehouse --target-tags=web-server --priority=900
```

- Firewall rules are checked in **priority** order, lowest number first. The default for a new rule is 1000, so 900 makes these denies win over `allow-internal`.
- `--source-tags` matches traffic by which tagged server sent it, so the rules keep working even if internal IPs change.
- IAP traffic comes from Google's range, not from either server, so admin SSH is unaffected.

**Check it worked:** under **VPC network → Firewall**, the list shows `allow-web`, both deny rules, and the Task 1 rules. From an SSH session on `vm2-web`, `ping -c 3 <warehouse-internal-ip>` should now time out. (Screenshot this list for the setup deliverable.)

**Outbound traffic:** `vm2-web` now reaches the internet through its own public IP. The warehouse still uses Cloud NAT for updates.

## 3. VM 1 (vm2-web): Choosing and preparing the platform

The store runs WordPress with the WooCommerce plugin on the existing Apache, MariaDB and PHP stack. Before installing it, we lock down the Task 1 phpMyAdmin (now that the server is public), add the PHP extensions WordPress needs, and create its database.

### Why WordPress + WooCommerce

| Platform | Strengths | Why not chosen |
| --- | --- | --- |
| **WordPress + WooCommerce** | Free; runs on our existing LAMP stack; most widely used e-commerce plugin; thousands of extensions, including shipment tracking for Task 8; huge documentation base | **Chosen** |
| OpenCart | Lightweight, built only for stores | Smaller plugin ecosystem; many extensions are paid; less help available |
| Zen Cart | Long-established, free | Dated admin interface and a steeper learning curve |
| Shopify (SaaS) | No server to maintain | Monthly fee, and it doesn't use the web server we built, which removes most of the learning goals |

The instructor's tip about Task 8 is the deciding factor: WooCommerce's plugin library means future features are an install, not custom code.

### Step 1: Restrict the existing phpMyAdmin

phpMyAdmin from Task 1 lives at `/phpmyadmin`. Once the public IP is attached, anyone on the internet could reach its login page and start guessing passwords. We allow it only from the server itself and from Google IAP (so the Task 1 tunnel method still works).

```bash
sudo nano /etc/apache2/conf-available/zz-phpmyadmin-restrict.conf
```

Paste the following, then save with Ctrl+O, Enter, and exit with Ctrl+X:

```apache
<Directory /usr/share/phpmyadmin>
    Require ip 127.0.0.1 35.235.240.0/20
</Directory>
```

```bash
sudo a2enconf zz-phpmyadmin-restrict
sudo systemctl reload apache2
```

- `Require ip` lets in only the listed addresses; everyone else gets **403 Forbidden**.
- The `zz-` prefix makes Apache load this file after phpMyAdmin's own settings, so ours wins.
- `a2enconf` switches the file on; `reload` applies it without dropping current visitors.

**Check it worked:** browsing `http://<static-ip>/phpmyadmin` from your own computer shows *Forbidden*. Through the IAP tunnel and Web Preview it still loads.

### Step 2: Install the PHP extensions WordPress uses

```bash
sudo apt install -y php-curl php-gd php-intl php-mbstring php-soap php-xml php-zip php-imagick
sudo systemctl restart apache2
```

| Extension | Used for |
| --- | --- |
| php-curl | Talking to other sites: plugin downloads, updates, payment gateways |
| php-gd, php-imagick | Resizing product images into thumbnails |
| php-intl, php-mbstring | Handling currencies, languages and non-English characters correctly |
| php-soap, php-xml | Data exchange used by WooCommerce and some shipping and payment extensions |
| php-zip | Installing plugins and themes uploaded as .zip files |

Without these, WordPress still installs but shows warnings in **Tools → Site Health**, and image uploads or plugin installs can fail.

### Step 3: Create the WordPress database and user

```bash
sudo mysql
```

```sql
CREATE DATABASE wordpress CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'wpuser'@'localhost' IDENTIFIED BY 'Choose-A-Strong-Password!';
GRANT ALL PRIVILEGES ON wordpress.* TO 'wpuser'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

- `utf8mb4` stores every character, including emoji and accented letters in product names or customer addresses. Older `utf8` in MariaDB can't.
- `wpuser` can reach only the `wordpress` database. If the site were ever hacked, the attacker's database access would stop there, away from `webstore` and the system tables.
- The Task 1 `webstore` database stays as it was; WordPress keeps its data separately in `wordpress`.

## 4. VM 1 (vm2-web): Installing WordPress

WordPress is downloaded from wordpress.org into Apache's web folder, handed to Apache's user, and finished through its browser installer at `http://<static-ip>`. Two Apache settings and a PHP upload limit are adjusted first so permalinks and product images work.

### Step 1: Download WordPress

```bash
cd /tmp
wget https://wordpress.org/latest.tar.gz
tar -xzf latest.tar.gz
```

- `wget` downloads the newest release straight from the official site, so it is current and untampered.
- `tar -xzf` unpacks the archive into `/tmp/wordpress`. `/tmp` is a scratch area that is cleaned automatically.

### Step 2: Put the files where Apache serves them

```bash
sudo mv /var/www/html/index.html /var/www/html/index.html.task1
sudo cp -a /tmp/wordpress/. /var/www/html/
sudo chown -R www-data:www-data /var/www/html
sudo find /var/www/html -type d -exec chmod 755 {} \;
sudo find /var/www/html -type f -exec chmod 644 {} \;
```

- The Apache default page (`index.html`) is renamed, not deleted, so it is kept as a record of Task 1. If left in place it would load instead of WordPress.
- `cp -a` copies everything, including hidden files, keeping the folder structure.
- `chown` makes `www-data` (the account Apache runs as) the owner. WordPress then can write its config file, save uploaded product images and install plugins.
- `755` for folders and `644` for files means only the owner can change them; everyone else can only read. This is WordPress's recommended permission set.

### Step 3: Let WordPress use pretty links

```bash
sudo nano /etc/apache2/conf-available/wordpress.conf
```

```apache
<Directory /var/www/html>
    AllowOverride All
</Directory>
```

```bash
sudo a2enconf wordpress
sudo a2enmod rewrite
```

- WordPress writes its link rules into a `.htaccess` file. `AllowOverride All` tells Apache to read that file; Ubuntu ignores it by default.
- `mod_rewrite` turns readable addresses such as `/product/coffee-mug/` into requests WordPress understands. Without it, product and checkout pages show 404 errors once permalinks are set.

### Step 4: Raise PHP's upload limits

PHP's default 2 MB upload limit rejects many product photos.

```bash
sudo nano /etc/php/8.3/apache2/conf.d/99-wordpress.ini
```

```ini
upload_max_filesize = 16M
post_max_size = 20M
memory_limit = 256M
max_execution_time = 120
```

```bash
sudo systemctl restart apache2
```

- A separate file in `conf.d` overrides `php.ini` without editing it, so an Ubuntu update to PHP won't undo the change.
- `post_max_size` must be larger than `upload_max_filesize`, because a form upload carries the file plus other fields.
- `memory_limit` 256M gives WooCommerce room on a 2 GB server; `max_execution_time` stops slow plugin installs timing out.

### Step 5: Run the web installer

On your own computer, browse to `http://<static-ip>`. This is the first test that the public IP and `allow-web` rule work.

| Installer screen | Enter | Why |
| --- | --- | --- |
| Language | English (United States) |  |
| Database name | `wordpress` | Created in section 3 |
| Username / Password | `wpuser` / its password | The limited account from section 3 |
| Database host | `localhost` | The database is on this same server |
| Table prefix | `wp_` (default) | Fine for a single site |
| Site title | Tallypoint Systems | Shown in the header and browser tab |
| Admin username | Something other than `admin` | `admin` is the first name attackers try |
| Admin password | WordPress's generated strong password | The login page is public, so it must be strong |
| Your email | Your address | Password resets and store notices |

The installer writes `wp-config.php` for you, including random security keys used to protect login cookies.

### Step 6: Basic settings after logging in

- **Settings → General:** confirm *WordPress Address* and *Site Address* both read `http://<static-ip>`. WordPress stores this address, which is why a static IP was required.
- **Settings → Permalinks:** choose **Post name**, then **Save Changes**. WordPress writes its `.htaccess` file.
- **Settings → General → Timezone:** choose *Los Angeles* so order times are correct.
- **Plugins:** delete the sample *Hello Dolly* and *Akismet* plugins if unused. Fewer plugins means less to patch.

**Check it worked:** `http://<static-ip>` shows the WordPress site, and `http://<static-ip>/wp-admin` shows the dashboard after login. (Screenshot the installer or dashboard for the setup deliverable.)

## 5. VM 1 (vm2-web): Building the store with WooCommerce

WooCommerce adds the shop, cart, checkout and customer account pages to WordPress. This section installs it, publishes 5 products, enables customer accounts and a test payment method, and runs an end-to-end checkout.

### Fast path: run the Tallypoint setup script

The script `tallypoint-store-setup.sh` performs steps 1 to 6 below in one run. It installs WooCommerce and the free Storefront theme, brands the site as Tallypoint Systems (logo, colors, Home and About pages, menu), creates four categories and nine products with images, and turns on customer accounts, shipping and two test payment methods. Step 7, testing as a customer, is still done by hand.

1. Finish the WordPress installer (section 4, step 5) and log in once.
2. Open **SSH** to `vm2-web` from the console. In the SSH window click **Upload file** and choose `tallypoint-store-setup.sh`. It lands in your home folder.
3. Run:

   ```bash
   sudo bash ~/tallypoint-store-setup.sh
   ```
4. It takes a few minutes and ends by printing the store, shop, About and admin addresses. Open the store address in a private window.

**Why a script:** it uses WP-CLI, WordPress's official command-line tool, so every setting is applied the same way each time. Repeatable configuration is easier to document, audit and rebuild than dozens of clicks. It is safe to run again: products are matched by SKU and updated rather than duplicated.

Two settings worth knowing:

- **Customers choose their own password** when they register. WooCommerce's default emails a generated password, but this server can't send email yet, so new customers would never receive it.
- **Software licenses and installation are virtual products**, so they skip shipping at checkout. Hardware ships at a flat $25, free on orders over $1,000.

To build the store by hand instead, continue with steps 1 to 6.

### Step 1: Install WooCommerce

1. In the WordPress dashboard, go to **Plugins → Add New Plugin** and search for **WooCommerce**.
2. Click **Install Now**, then **Activate**.
3. The setup wizard opens. Enter the store's country and address, choose currency **US Dollar**, and skip optional add-ons such as Jetpack or marketing tools. Extras can be added later and each one is more code to patch.

WooCommerce automatically creates four pages: **Shop**, **Cart**, **Checkout** and **My account**.

**Theme (optional):** the default WordPress theme works with WooCommerce. For a more classic store layout, go to **Appearance → Themes → Add New Theme**, search **Storefront** (WooCommerce's own free theme), install and activate it.

### Step 2: Make the store visible

New WooCommerce stores start in **Coming soon** mode, which shows visitors a placeholder page instead of products. Go to **WooCommerce → Settings → Site visibility**, choose **Live**, and save. Forgetting this is the most common reason a finished store looks empty.

### Step 3: Set up shipping

Checkout refuses to complete when no shipping method covers the customer's address.

1. Go to **WooCommerce → Settings → Shipping → Add zone**.
2. Name it *United States*, set the region to **United States (US)**.
3. Add a shipping method: **Flat rate** (for example $5.00) or **Free shipping**. Save.

### Step 4: Add five products

The catalog comes from the Tallypoint company profile: the POS app sold as a monthly license, the complete hardware bundle, individual peripherals, and on-site installation. The bundle and terminal SKUs match the warehouse database (section 7), so the two systems could be linked later without renaming anything.

| Product | Category | Price (USD) | SKU | Stock |
| --- | --- | --- | --- | --- |
| Tallypoint POS Essentials – 1-Month License | Software | 69.00 | TP-SW-ESS | Virtual |
| Tallypoint POS Pro – 1-Month License | Software | 129.00 | TP-SW-PRO | Virtual |
| Tallypoint Complete POS Bundle | POS Bundles | 1,899.00 | TP-BND-CMP | 22 |
| Tallypoint 15" Touchscreen Terminal | Hardware | 1,099.00 | TP-HW-TRM | 30 |
| Thermal Receipt Printer | Hardware | 329.00 | TP-HW-PRN | 60 |
| 2D Barcode Scanner with Stand | Hardware | 189.00, on sale 169.00 | TP-HW-SCN | 75 |
| Heavy-Duty Cash Drawer | Hardware | 159.00 | TP-HW-DRW | 40 |
| EMV & Contactless Card Reader | Hardware | 279.00 | TP-HW-CRD | 15 |
| On-Site Installation & Training | Services | 499.00 | TP-SVC-INS | Virtual |

For each product, go to **Products → Add New Product**:

1. **Product name** at the top, and a full **description** in the main box.
2. **Product data → General:** enter the **Regular price**.
3. **Inventory tab:** enter the **SKU**, tick **Track stock quantity**, and set a quantity such as 25. Customers then can't buy more than you have.
4. **Product short description:** one line shown next to the price.
5. **Product image** (right side): upload a photo. Use your own photos or free-license images from sites like Unsplash or Pexels; don't copy images from other stores.
6. **Product categories:** create one such as *Home Goods*.
7. Click **Publish**.

**Why SKUs:** a SKU (stock keeping unit) is the code that identifies an item everywhere. Using the same SKUs in the store and the warehouse means the systems could be linked later without renaming anything.

Shortcut: WooCommerce includes a sample product file. **Products → Import**, choose `wp-content/plugins/woocommerce/sample-data/sample_products.csv` from the server. Creating your own five is better evidence for this assignment.

### Step 5: Allow customer accounts

Go to **WooCommerce → Settings → Accounts & Privacy** and tick:

- **Allow customers to create an account on the "My account" page**
- **Allow customers to create an account during checkout**

Save. Customers can now register, log in to see their orders, and save their address for next time.

### Step 6: Enable a test payment method

Go to **WooCommerce → Settings → Payments**. Under the offline payment methods, enable **Cash on delivery** or **Check payments**, and save. (The exact layout of this page changes between WooCommerce versions, but the offline methods are always included.)

**Why an offline method:** real card gateways such as Stripe or WooPayments need a business account and, for live cards, HTTPS and verified identity. An offline method completes the full order workflow with no real money involved, which is what the assignment needs to demonstrate.

### Step 7: Test the customer journey end to end

Use a **private/incognito browser window**, so you are a customer, not the logged-in admin.

1. Open `http://<static-ip>/my-account/`, fill in **Register** (email and password), and submit. You are now logged in as a customer.
2. Log out, then log back in, to prove login works.
3. Go to **Shop**, open a product, click **Add to cart**, then **View cart → Proceed to checkout**.
4. Fill in a US billing address, pick the shipping method and your offline payment, and click **Place order**.
5. The **Order received** page appears with an order number.

Back in the admin window, **WooCommerce → Orders** lists the new order (status *Processing* or *On hold*, depending on the payment method), and the product's stock dropped by one.

**Note on order emails:** `vm2-web` has no mail server, so WooCommerce's confirmation emails won't be delivered. Orders still complete normally; email can be connected in a later task.

**Screenshots for submission:** the Tallypoint home page and the Shop page showing all nine products, the Order received page, and the order listed in **WooCommerce → Orders**.

## 6. VM 1 (vm2-web): HTTPS (optional, recommended)

HTTPS encrypts everything between the customer and the store, including passwords and addresses. It needs a free certificate from Let's Encrypt, which in turn needs a hostname. If you don't own a domain, a free wildcard-DNS name such as `203-0-113-10.sslip.io` works: it simply points to the IP written in it.

**Do this only after the store works over HTTP.** If something goes wrong, the HTTP site from section 5 is unaffected until the final step.

### Why it matters

- Without HTTPS, browsers mark the login and checkout pages *Not secure*, and customer passwords cross the internet in plain text.
- Real payment gateways require HTTPS before they will take live cards.
- Let's Encrypt certificates are free, trusted by every browser, and renew automatically.

### Step 1: Give Apache the hostname

Replace the dots in your static IP with dashes and add `.sslip.io`. For an IP of 203.0.113.10 the hostname is `203-0-113-10.sslip.io`. Check it resolves:

```bash
host 203-0-113-10.sslip.io
```

Then tell Apache its name:

```bash
sudo nano /etc/apache2/sites-available/000-default.conf
```

Under the `<VirtualHost *:80>` line, add `ServerName 203-0-113-10.sslip.io` (with your own IP), save, then:

```bash
sudo apachectl configtest && sudo systemctl reload apache2
```

`configtest` checks the file for typos before reloading, so a mistake can't take the site down.

### Step 2: Get and install the certificate

```bash
sudo apt install -y certbot python3-certbot-apache
sudo certbot --apache -d 203-0-113-10.sslip.io
```

- Certbot proves you control the hostname by having Let's Encrypt fetch a temporary file over port 80. That works because `allow-web` opens port 80.
- Enter your email for expiry notices and agree to the terms. When asked, choose to **redirect** HTTP to HTTPS.
- Certbot edits Apache's config to use the certificate and installs a timer that renews it before its 90-day expiry. Test renewal with `sudo certbot renew --dry-run`.

If Certbot reports a rate limit, the shared sslip.io domain has hit Let's Encrypt's weekly cap. Wait and retry, or skip HTTPS; it is optional for this task.

### Step 3: Switch WordPress to the new address

In **Settings → General**, change both *WordPress Address* and *Site Address* to `https://203-0-113-10.sslip.io` and save. You'll be asked to log in again at the new address.

Update the guide's `<static-ip>` references to the hostname for later tasks. Existing product images may still point at `http://<static-ip>`; they still load (the redirect handles them), and re-saving a product refreshes its links.

## 7. VM 2 (vm1-warehouse-db): Securing and populating the inventory database

The warehouse server keeps no public IP, MariaDB listens only on the server itself, and a host firewall adds a second layer behind Google's. The `inventory` table is expanded to track Tallypoint's vendor components, finished terminals and bundles, and packaging supplies: twelve items with suppliers, plus an audit log.

### Step 1: Confirm the server is isolated

In **Compute Engine → VM instances**, `vm1-warehouse-db` shows an internal IP and no external IP. Then, on the server:

```bash
sudo ss -tlnp | grep -E '3306|:80 '
```

- `ss -tlnp` lists every port the server is listening on and which program owns it.
- MariaDB should show `127.0.0.1:3306`. That means the database accepts connections only from programs on this server; even another server on the private network can't reach it. This is Ubuntu's default and we keep it.

### Step 2: Add a host firewall (defense in depth)

Google's firewall already blocks the internet. A second firewall on the server itself means that if a cloud rule were ever changed by mistake, the server would still refuse unexpected traffic. Ubuntu's tool for this is **ufw** (uncomplicated firewall).

Run these **in this order**. Enabling ufw before allowing SSH would lock you out.

```bash
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow from 35.235.240.0/20 to any port 22 proto tcp
sudo ufw allow from 35.235.240.0/20 to any port 80 proto tcp
sudo ufw enable
sudo ufw status verbose
```

- `default deny incoming` drops anything not explicitly allowed, including port 3306.
- The two `allow` lines admit SSH and the phpMyAdmin tunnel only from Google IAP's range.
- `default allow outgoing` keeps updates through Cloud NAT working.
- `ufw status verbose` prints the rules: a good setup screenshot proving the database port is restricted.

### Step 3: Expand the inventory table

```bash
sudo mysql warehouse
```

**Fast path:** steps 3 and 4 (and the audit table from step 5) are packaged in `tallypoint-warehouse.sql`. Upload it through the SSH window's **Upload file** button and run:

```bash
sudo mysql warehouse < ~/tallypoint-warehouse.sql
```

It prints the inventory and the low-stock list when it finishes, and is safe to run again. The SQL it runs is shown below so the steps are documented.

```sql
-- Add the columns a real warehouse needs (only if missing)
ALTER TABLE inventory
  ADD COLUMN IF NOT EXISTS sku VARCHAR(20) AFTER item_id,
  ADD COLUMN IF NOT EXISTS category ENUM('Raw material','Finished good','Supply')
      NOT NULL DEFAULT 'Finished good' AFTER item_name,
  ADD COLUMN IF NOT EXISTS unit VARCHAR(10) NOT NULL DEFAULT 'each' AFTER quantity,
  ADD COLUMN IF NOT EXISTS reorder_level INT NOT NULL DEFAULT 0 AFTER unit,
  ADD COLUMN IF NOT EXISTS supplier VARCHAR(60) AFTER location,
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP
      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

ALTER TABLE inventory ADD UNIQUE INDEX IF NOT EXISTS uq_inventory_sku (sku);

-- Remove the Task 1 placeholder rows
DELETE FROM inventory WHERE item_name IN ('Widget A', 'Widget B', 'Gadget C');
```

| New column | Purpose |
| --- | --- |
| `sku` | The item's code. Finished goods use the same SKU as the store. The unique index stops two items sharing a code. |
| `category` | Raw material, finished good or supply. `ENUM` allows only those three values, so typos can't create a fourth. |
| `unit` | What the quantity counts: each, licenses, sets, rolls, labels. |
| `reorder_level` | When stock falls to this number, it is time to reorder from the supplier. |
| `supplier` | The vendor the item is bought from, taken from Tallypoint's supply chain. |
| `updated_at` | Set automatically whenever a row changes, so auditors can see when a count last moved. |

`IF NOT EXISTS` is a MariaDB feature that makes the script safe to rerun: a column that already exists is skipped instead of causing an error.

### Step 4: Add the inventory items

```sql
INSERT INTO inventory
  (sku, item_name, category, quantity, unit, reorder_level, location, supplier)
VALUES
  ('RM-TRM-15',  '15-inch touchscreen terminal (unimaged)', 'Raw material',   64, 'each',     20, 'Receiving Bay A', 'Elo Touch'),
  ('RM-PRN-80',  '80 mm thermal receipt printer',           'Raw material',   85, 'each',     25, 'Bay A, Rack 2',   'Star Micronics'),
  ('RM-SCN-2D',  '2D barcode scanner with stand',           'Raw material',  110, 'each',     30, 'Bay B, Rack 1',   'Honeywell'),
  ('RM-DRW-HD',  'Heavy-duty cash drawer',                  'Raw material',   48, 'each',     20, 'Bay B, Floor',    'APG'),
  ('RM-CRD-EMV', 'EMV and contactless card reader',         'Raw material',   15, 'each',     25, 'Secure cage',     'Verifone'),
  ('RM-LIC-IOT', 'Windows IoT Enterprise license',          'Raw material',  140, 'licenses', 50, 'License vault',   'Microsoft'),
  ('TP-HW-TRM',  'Imaged 15-inch terminal, Tallypoint POS', 'Finished good',  30, 'each',     10, 'Staging, Rack 3', 'Tallypoint fulfillment'),
  ('TP-BND-CMP', 'Complete POS Bundle, boxed',              'Finished good',  22, 'each',     10, 'Outbound dock',   'Tallypoint fulfillment'),
  ('SP-BOX-BND', 'Bundle shipping carton',                  'Supply',        200, 'each',     60, 'Packaging aisle', 'Packaging supplier'),
  ('SP-FOAM-IN', 'Foam insert set for bundle carton',       'Supply',        180, 'sets',     60, 'Packaging aisle', 'Packaging supplier'),
  ('SP-PPR-80',  '80 mm thermal paper roll',                'Supply',        400, 'rolls',   150, 'Bay A, Rack 4',   'Office supply vendor'),
  ('SP-LBL-SHP', 'Carrier shipping labels',                 'Supply',       1500, 'labels',  500, 'Outbound dock',   'UPS / FedEx')
ON DUPLICATE KEY UPDATE
  item_name = VALUES(item_name), category = VALUES(category), quantity = VALUES(quantity),
  unit = VALUES(unit), reorder_level = VALUES(reorder_level),
  location = VALUES(location), supplier = VALUES(supplier);
```

The items follow Tallypoint's supply chain. **Raw materials** are components received from its hardware vendors, plus Windows licenses from Microsoft. **Finished goods** are what the fulfillment team produces: terminals imaged with Tallypoint and boxed POS bundles. **Supplies** are the packaging and labels used to ship them. The card reader is deliberately below its reorder level, so the low-stock check has something to find.

`ON DUPLICATE KEY UPDATE` means that if a SKU already exists, its row is updated instead of failing, which is why the file can be rerun.

### Step 5: Add an audit log and a read-only auditor

Auditing means checking that recorded stock matches what is physically on the shelf, and keeping a record of each check.

```sql
CREATE TABLE IF NOT EXISTS inventory_audit (
  audit_id    INT AUTO_INCREMENT PRIMARY KEY,
  item_id     INT NOT NULL,
  counted_qty INT NOT NULL,
  audited_by  VARCHAR(50) NOT NULL,
  audited_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  notes       VARCHAR(255),
  FOREIGN KEY (item_id) REFERENCES inventory(item_id)
);

CREATE USER 'warehouse_auditor'@'localhost' IDENTIFIED BY 'Another-Strong-Password!';
GRANT SELECT ON warehouse.* TO 'warehouse_auditor'@'localhost';
GRANT INSERT ON warehouse.inventory_audit TO 'warehouse_auditor'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

- The `FOREIGN KEY` means an audit can only be recorded against an item that actually exists.
- `warehouse_auditor` can read everything and log counts, but cannot change stock levels or delete records. Separating the person who counts from the person who adjusts stock is a standard control against errors and theft.
- `warehouse_admin` (from Task 1) remains the full administrator for the `warehouse` database.

### Step 6: Verify

```sql
SELECT sku, item_name, category, quantity, unit FROM inventory ORDER BY category, item_name;

-- Items that need reordering
SELECT sku, item_name, quantity, reorder_level FROM inventory WHERE quantity <= reorder_level;
```

The first query returns all twelve items grouped by category; the second returns the EMV card reader (15 on hand, reorder at 25).

## 8. VM 2 (vm1-warehouse-db): Secure inventory portal

Warehouse staff manage inventory through phpMyAdmin on the warehouse server, reached only through an encrypted IAP tunnel. Administrators log in as `warehouse_admin` to edit stock; auditors log in as `warehouse_auditor` to view and record counts.

### Why phpMyAdmin for the portal

| Option | Why |
| --- | --- |
| **phpMyAdmin** | **Chosen.** Already familiar from Task 1, free, works directly with our MariaDB tables, and respects the database permissions we set (an auditor really can't edit stock). |
| WordPress + WP Inventory plugin | Friendlier screens, but adds a second WordPress to patch, and stores inventory in WordPress's own tables instead of our designed schema. |
| Custom PHP page | Most tailored, but takes development time and needs its own security review. |

### Step 1: Install Apache, PHP and phpMyAdmin

```bash
sudo apt install -y apache2 php libapache2-mod-php php-mysql php-mbstring
sudo apt install -y phpmyadmin
```

Answer the phpMyAdmin prompts as in Task 1: press **Space** to mark **apache2**, choose **Yes** for dbconfig-common, and set a strong application password.

- Apache serves the portal; PHP runs phpMyAdmin; `php-mysql` lets it talk to MariaDB; `php-mbstring` handles text safely.
- Only port 80 is used, and only over the IAP tunnel, so the traffic is still encrypted end to end by IAP.

### Step 2: Restrict the portal to IAP

This is the same restriction used on the store server. The cloud firewall and ufw already enforce it; repeating it in Apache means three independent layers would all have to fail before anyone else reached the login page.

```bash
sudo nano /etc/apache2/conf-available/zz-phpmyadmin-restrict.conf
```

```apache
<Directory /usr/share/phpmyadmin>
    Require ip 127.0.0.1 35.235.240.0/20
</Directory>
```

```bash
sudo a2enconf zz-phpmyadmin-restrict
sudo systemctl reload apache2
```

### Step 3: Open the portal

In Cloud Shell:

```bash
gcloud compute start-iap-tunnel vm1-warehouse-db 80 \
  --local-host-port=localhost:8081 --zone=us-west1-b
```

When it prints `Listening on port [8081]`, click **Web Preview → Change port**, enter **8081**, and click **Change and Preview**. Add `/phpmyadmin` to the end of the address in the new tab.

Port 8081 (instead of 8080) means the store's tunnel can stay open at the same time if needed.

### Step 4: Administrator login and inventory management

Log in as `warehouse_admin`. In the left panel, open **warehouse → inventory**.

- **View live records:** the **Browse** tab shows all twelve items. Click a column header (such as *category*) to sort.
- **Edit stock:** click **Edit** on the card reader row (RM-CRD-EMV), change *quantity* from 15 to 65 (a Verifone delivery arrived), and click **Go**. The `updated_at` column changes automatically.
- **Find low stock:** on the **SQL** tab, run `SELECT sku, item_name, quantity, reorder_level FROM inventory WHERE quantity <= reorder_level;`.

### Step 5: Record an audit

Still as admin (or as the auditor), open **inventory\_audit → Insert** and add a row: *item\_id* of the imaged terminal (TP-HW-TRM), *counted\_qty* 30, *audited\_by* your name, *notes* "Shelf count matches". Then **Browse** the table to show the audit history.

### Step 6: Prove the access controls work

Log out, then log in as `warehouse_auditor`.

- Browsing `inventory` works.
- Trying to **Edit** a quantity fails with an error saying the UPDATE command is denied.
- Inserting into `inventory_audit` works.

That error is the evidence that permissions are enforced by the database itself, not just by the portal's screens.

**Screenshots for submission:** phpMyAdmin logged in as `warehouse_admin` showing the inventory table with all twelve items (end result), and optionally the auditor's denied-edit error. Press Ctrl+C in Cloud Shell to close the tunnel when done.

## 9. Deliverables, shutdown and troubleshooting

The assignment needs at least 5 labeled screenshots: 2 setup, 1 VM separation and 2 end result. The list below gives 9, so you can choose the clearest.

### Screenshot checklist

| # | Type | Screenshot | Caption idea |
| --- | --- | --- | --- |
| 1 | Setup | VPC network → Firewall, showing `allow-web` and both deny rules | Web ports open only to the store; store and warehouse blocked from each other |
| 2 | Setup | VPC network → IP addresses, showing `store-ip` in use by `vm2-web` | Reserved static IP keeps WordPress links stable |
| 3 | Setup | WordPress installer or WooCommerce setup screen | E-commerce platform installed on the Task 1 LAMP stack |
| 4 | Setup | `sudo ufw status verbose` on the warehouse server | Host firewall allows only IAP; database port 3306 closed |
| 5 | **Separation** | Compute Engine → VM instances, both running, names, internal IPs and the store's external IP visible | Two independent servers: a public store and a private warehouse |
| 6 | End result | Shop page listing all nine Tallypoint products with images and prices | Customer-facing store with product catalog |
| 7 | End result | Order received page after checkout as a registered customer | Registration, login and checkout work end to end |
| 8 | End result | phpMyAdmin as `warehouse_admin`, inventory table with twelve Tallypoint items | Internal inventory portal with administrative access |
| 9 | End result (optional) | Auditor's "UPDATE command denied" error | Database permissions enforce read-only auditing |

Keep the server name visible in terminal screenshots, and crop out any passwords.

### Shutdown

When screenshots and testing are done, stop both servers:

```bash
gcloud compute instances stop vm1-warehouse-db vm2-web --zone=us-west1-b
```

- The static IP stays reserved, so the store comes back at the same address and WordPress keeps working.
- A reserved IP attached to a **stopped** server is billed at the higher unused rate. That's a small cost compared with breaking the site, but release it (`gcloud compute addresses delete store-ip --region=us-west1`) once the course no longer needs the store.
- Data, WordPress content and inventory records all survive a stop.

### Troubleshooting

| Symptom | Likely cause | Fix |
| --- | --- | --- |
| `http://<static-ip>` times out | `web-server` tag missing, or `allow-web` on the wrong network | `gcloud compute instances describe vm2-web --zone=us-west1-b --format='value(tags.items)'` should list `web-server` |
| Apache default page shows instead of WordPress | `index.html` still in `/var/www/html` | Rename it (section 4, step 2) |
| "Error establishing a database connection" | Wrong `wpuser` password or database name | Check `/var/www/html/wp-config.php`, or reset the password with `ALTER USER` |
| Product or checkout pages return 404 | `mod_rewrite` or `AllowOverride` missing | Redo section 4, step 3, then re-save **Settings → Permalinks** |
| Visitors see a "Coming soon" page | Store still in Coming soon mode | **WooCommerce → Settings → Site visibility → Live** |
| Checkout says no shipping options | No shipping zone covers the address | Section 5, step 3 |
| Image upload fails "exceeds the maximum upload size" | PHP limits not raised | Section 4, step 4, then restart Apache |
| Site breaks after the server restarts | Address changed (ephemeral IP) | Use the reserved `store-ip`; check **Settings → General** addresses match it |
| SSH stops working after enabling ufw | ufw enabled before the SSH allow rule | Use the console's **serial console**, or detach the boot disk and fix it; next time run the ufw commands in order |
| `/phpmyadmin` says Forbidden through the tunnel | Wrong IP range in the restrict file | It must be exactly `35.235.240.0/20` |

### Sources

- [Use IAP for TCP forwarding](https://docs.cloud.google.com/iap/docs/using-tcp-forwarding) (Google Cloud): IAP address range, SSH and `start-iap-tunnel`.

Further reading for this build: [Reserving a static external IP address](https://cloud.google.com/compute/docs/ip-addresses/reserve-static-external-ip-address), [VPC firewall rules](https://cloud.google.com/firewall/docs/firewalls), [WordPress installation guide](https://developer.wordpress.org/advanced-administration/before-install/howto-install/), [WooCommerce documentation](https://woocommerce.com/documentation/woocommerce/), [Certbot instructions](https://certbot.eff.org/), [Ubuntu ufw guide](https://documentation.ubuntu.com/server/how-to/security/firewalls/).
