# Task 2: Configuration Report and Screenshot Log

Tallypoint Systems · e-commerce server and warehouse inventory system

> Screenshots are redacted: the Linux username in terminal prompts and the WordPress admin username are covered. No public IP addresses, project IDs or passwords appear in this repository.

## System configuration documentation

Both Task 1 servers were upgraded in place on the private `smallbiz-vpc` network (10.10.0.0/24, us-west1). The web server, `vm2-web`, became the public e-commerce server (VM 1), and the database server, `vm1-warehouse-db`, became the private warehouse inventory system (VM 2).

### VM 1: E-commerce server (vm2-web)

For the store, a regional static external IP (`store-ip`) was reserved and attached to `vm2-web`, so WordPress's saved site address and image links stay stable across restarts. A firewall rule, `allow-web`, opens TCP 80 and 443 from any address but only to instances tagged `web-server`. Two priority-900 deny rules block all traffic between the `web-server` and `warehouse` tags, and SSH stays restricted to Google IAP (35.235.240.0/20). Before the server went public, the Task 1 phpMyAdmin page was restricted with an Apache `Require ip` rule.

On `vm2-web`, the PHP extensions WordPress needs were installed: curl, gd, intl, mbstring, soap, xml, zip and imagick. A `wordpress` database (utf8mb4) and a limited `wpuser` account were created in MariaDB. WordPress was then downloaded into `/var/www/html`, owned by Apache's `www-data` user, with `mod_rewrite` and `AllowOverride` enabled for readable URLs, and installed through its web installer.

A setup script using WP-CLI, WordPress's command-line tool, then configured the store ([`web-server/store-setup`](../web-server/store-setup)):

- installed WooCommerce and the Storefront theme
- applied the Tallypoint name, logo and colors, and created the Home and About pages and the main menu
- created four product categories and nine products with prices, descriptions, SKUs, stock levels and images
- turned on customer registration, with customers choosing their own password because the server can't send email
- enabled two offline test payment methods, invoice and pay on delivery
- added a US shipping zone with a $25 flat rate, free over $1,000
- set the store live and turned on post-name permalinks

Registration, login and checkout were then tested end to end in a private browser window.

### VM 2: Warehouse inventory system (vm1-warehouse-db)

On `vm1-warehouse-db`, which has no external IP, MariaDB stays bound to 127.0.0.1. UFW was enabled to deny all incoming traffic except SSH and HTTP from IAP. A SQL script ([`tallypoint-warehouse.sql`](../warehouse-server/tallypoint-warehouse.sql)) did the following:

- added `sku`, `category`, `unit`, `reorder_level`, `supplier` and `updated_at` columns and a unique SKU index to the `inventory` table
- removed the Task 1 placeholder rows
- loaded 12 Tallypoint items: vendor components from Elo Touch, Star Micronics, Honeywell, APG, Verifone and Microsoft, imaged terminals and boxed bundles, and packaging supplies
- created an `inventory_audit` table for stock counts

A read-only `warehouse_auditor` account was added alongside `warehouse_admin`. Finally, Apache, PHP and phpMyAdmin were installed and restricted to localhost and the IAP range. Administrators reach the portal through an IAP tunnel opened from Cloud Shell (port 8081, Web Preview) to view, edit and audit live inventory records.

## Screenshots

### Setup

![Host firewall on the warehouse server](images/01-warehouse-host-firewall.png)

**Figure 1: Host firewall on the warehouse server (vm1-warehouse-db).** UFW (Uncomplicated Firewall) was enabled with a default-deny policy for incoming traffic. It allows only SSH (port 22) and the phpMyAdmin web portal (port 80) from Google's IAP address range, 35.235.240.0/20, so the database port 3306 can't be reached from any other machine. The line above the rules shows the low-stock check flagging the EMV card reader (15 on hand, reorder level 25).

![WooCommerce installed](images/02-woocommerce-installed.png)

**Figure 2: WooCommerce installed on the e-commerce server (vm2-web).** WordPress was installed on the Task 1 LAMP stack (Linux, Apache, MariaDB, PHP), the WooCommerce plugin was activated, and the store was named Tallypoint Systems. This was taken before the catalog was loaded, while the store was still in "Coming soon" mode. The setup script added the products, payments and branding afterward, so the wizard's checklist stays at 0 of 5.

![Warehouse administrator account verified](images/03-warehouse-admin-verified.png)

**Figure 3: Warehouse database administrator account verified.** The `warehouse_admin` account logged in and counted the rows in the `inventory` table. The count of 12 confirms that the Tallypoint inventory data loaded.

![Inventory table structure](images/04-inventory-table-structure.png)

**Figure 4: Inventory table structure.** The Task 1 `inventory` table was upgraded with the following columns:

- `sku`, with a unique index, so no two items can share a code
- `category`, limited to Raw material, Finished good or Supply
- `unit`, `reorder_level` and `supplier`
- `updated_at`, an automatic timestamp

The `inventory_audit` table, listed on the left, records physical stock counts.

![Google Cloud firewall rules](images/05-gcp-firewall-rules.png)

**Figure 5: Google Cloud firewall rules.** On the `smallbiz-vpc` network:

- `allow-web` opens ports 80 and 443 only to servers tagged `web-server`, which is only the store.
- `allow-iap` limits SSH and the admin portal to Google IAP.
- `deny-web-to-warehouse` and `deny-warehouse-to-web` (priority 900) block all traffic between the store and the warehouse, which overrides `allow-internal`.

The `default-*` rules belong to Google's unused default network and don't apply to either server.

### End result

![Tallypoint storefront](images/06-storefront-home.png)

**Figure 6: Live Tallypoint Systems storefront.** The public home page, served from the reserved static IP, uses the Storefront theme with the Tallypoint logo, brand colors and a menu covering POS Bundles, Software, Hardware, Services, About and My Account. The admin bar shows the store's status as **Live**.

![Product catalog](images/07-shop-catalog.png)

**Figure 7: Product catalog.** The Shop page lists all 9 Tallypoint products, each with an image, price and Add to cart button:

- two POS software licenses
- the Complete POS Bundle
- five hardware items, with the barcode scanner on sale
- the On-Site Installation & Training service

![phpMyAdmin portal](images/08-phpmyadmin-portal.png)

**Figure 8: phpMyAdmin portal on the warehouse server.** The administrator is logged in to phpMyAdmin through an encrypted IAP tunnel. The Database server panel confirms the session is `warehouse_admin@localhost` on MariaDB 10.11 running Ubuntu 24.04. The account can see only the `warehouse` database, which shows that its permissions are limited to that database.
