# Small Business Network – Task 1 Setup Guide

## 1. Overview

Three private Ubuntu servers in Google Cloud provide the company's warehouse database, web server with its own database, and email server. None of them has a public IP address, so none can be reached from the internet.

This guide records every step used to build the environment, with the reason behind each choice. It is written so another administrator could rebuild the network from scratch by following it in order.

| Server | Role | Software | OS | Machine type |
| --- | --- | --- | --- | --- |
| vm1-warehouse-db | Warehouse SQL database | MariaDB | Ubuntu 24.04 LTS | e2-small (2 vCPU burst, 2 GB RAM) |
| vm2-web | Web server + web database | Apache, MariaDB, PHP, phpMyAdmin | Ubuntu 24.04 LTS | e2-small |
| vm3-mail | Email server | Postfix, mailutils | Ubuntu 24.04 LTS | e2-small |

**How to use this guide.** Build the network first (section 2), then create the servers (section 3), then configure each server (sections 4 to 6). Section 7 lists the screenshots that prove each server works.

**Conventions.** Commands in code blocks are typed into the server's terminal. Lines starting with `#` are comments and do not need to be typed. Replace any password shown with your own strong password, and never record real passwords in this document.

## 2. Private network (VPC)

All three servers live on a custom private network called `smallbiz-vpc`. Administrators get in only through Google's Identity-Aware Proxy (IAP), and the servers reach the internet only outbound, for software updates.

```mermaid
flowchart LR
  admin["Administrator<br/>Browser / Cloud Shell"] --> iap["Google IAP<br/>35.235.240.0/20"]
  subgraph vpc["smallbiz-vpc · 10.10.0.0/24 · us-west1"]
    vm1["vm1-warehouse-db<br/>MariaDB: warehouse"]
    vm2["vm2-web<br/>Apache · PHP · MariaDB · phpMyAdmin"]
    vm3["vm3-mail<br/>Postfix + mailutils"]
  end
  iap -- "SSH 22 / HTTP 80" --> vm1
  iap -- "SSH 22 / HTTP 80" --> vm2
  iap -- "SSH 22 / HTTP 80" --> vm3
  vm1 & vm2 & vm3 -- "outbound only (apt)" --> nat["Cloud NAT<br/>smallbiz-router"] --> net["Internet"]
```

*Network layout: three servers, admin access only through IAP, outbound-only internet through NAT.*

There is no arrow from the internet to any server: nothing outside can open a connection to them.

### Why a custom network instead of the default one

Every Google Cloud project comes with a `default` network. Its pre-made firewall rules allow SSH (port 22), RDP (port 3389) and ping from **any address on the internet** (0.0.0.0/0). Combined with public IPs, that is how student VMs get hijacked.

A custom network starts with nothing allowed in. We then open only the two paths we need. This is the principle of **least privilege**: grant the minimum access required, nothing more.

### The components and why each exists

| Component | Setting | Why |
| --- | --- | --- |
| VPC `smallbiz-vpc` | Custom subnet mode | We choose the address range and region instead of Google creating subnets in every region. |
| Subnet `smallbiz-subnet` | 10.10.0.0/24, us-west1 | A /24 gives 256 addresses (about 250 usable), plenty for a small business. us-west1 (Oregon) is a low-cost US region close to the team, so connections feel faster. |
| Private Google Access | On | Lets servers with no public IP still reach Google services such as Cloud Storage. |
| Flow logs | Off | They record every connection, which adds logging charges we don't need. |
| Firewall `allow-internal` | All traffic from 10.10.0.0/24 | Servers can talk to each other. Later tasks will need this, for example the web server querying the warehouse database. |
| Firewall `allow-iap` | TCP 22 and 80 from 35.235.240.0/20 | 35.235.240.0/20 is the address range Google IAP connects from. Only IAP can reach SSH and the web page, and IAP first checks you are signed in to the Google account that owns the project. |
| Cloud Router + Cloud NAT | Auto-allocated NAT IP | Servers without public IPs can't download updates. NAT lets them start outbound connections while blocking anything from starting a connection in. |

### Commands (run in Cloud Shell)

Open Cloud Shell with the `>_` icon at the top right of the Google Cloud console. The first line saves the region in a variable so it is typed once.

```bash
REGION=us-west1

# 1. Create the empty network; we'll define subnets ourselves
gcloud compute networks create smallbiz-vpc --subnet-mode=custom

# 2. Create the subnet with its address range and Private Google Access
gcloud compute networks subnets create smallbiz-subnet \
  --network=smallbiz-vpc --region=$REGION --range=10.10.0.0/24 \
  --enable-private-ip-google-access

# 3. Let the servers talk to each other
gcloud compute firewall-rules create allow-internal \
  --network=smallbiz-vpc --direction=INGRESS --action=ALLOW \
  --rules=all --source-ranges=10.10.0.0/24

# 4. Let only Google IAP reach SSH (22) and web (80)
gcloud compute firewall-rules create allow-iap \
  --network=smallbiz-vpc --direction=INGRESS --action=ALLOW \
  --rules=tcp:22,tcp:80 --source-ranges=35.235.240.0/20

# 5. Create a Cloud Router (NAT needs one to attach to)
gcloud compute routers create smallbiz-router \
  --network=smallbiz-vpc --region=$REGION

# 6. Create the NAT gateway for outbound-only internet access
gcloud compute routers nats create smallbiz-nat \
  --router=smallbiz-router --region=$REGION \
  --auto-allocate-nat-external-ips --nat-all-subnet-ip-ranges
```

What the less obvious options mean:

- `--direction=INGRESS` means the rule applies to traffic coming **into** the servers.
- `--source-ranges` is who the traffic may come from. Anything not listed is dropped by the network's built-in deny-all rule.
- `--auto-allocate-nat-external-ips` lets Google pick the NAT's public address. That address belongs to the NAT gateway, not to any server.
- `--nat-all-subnet-ip-ranges` applies the NAT to every subnet in the network.

**Check it worked:** each command prints `Created`. Under **VPC network → VPC networks**, `smallbiz-vpc` appears with one subnet.

## 3. Creating the servers

All three servers are Ubuntu Server 24.04 LTS on e2-small machines, attached to `smallbiz-subnet` with no public IP. One loop in Cloud Shell creates all three identically.

### Why Ubuntu Server 24.04 LTS

| Option | Considered because | Decision |
| --- | --- | --- |
| **Ubuntu 24.04 LTS** | Free image, huge documentation base, simple `apt` package manager | **Chosen** |
| Windows Server + SQL Server | Familiar GUI and SSMS | Rejected: Windows adds a per-hour license charge to every VM and needs about 4 GB RAM or more, which uses cloud credit quickly |
| Debian 12 | Very stable, Ubuntu is based on it | Would work; Ubuntu has more beginner tutorials for each package we install |
| Rocky Linux / RHEL-style | Common in enterprises | Would work; uses different tools (`dnf`, SELinux) that add setup steps |

**LTS** means Long Term Support: Canonical provides security updates for 24.04 until 2029. Businesses choose LTS releases so they aren't forced to upgrade every few months. Using the same OS on all three servers also means one set of commands and one patching routine.

### Why these machine settings

- **e2-small (2 shared vCPUs, 2 GB RAM).** Enough for MariaDB, Apache or Postfix under light load, at a fraction of the cost of larger types. A server can be resized later by stopping it and changing its machine type.
- **20 GB balanced persistent disk.** The 10 GB default gets tight once updates and databases are added. "Balanced" is SSD-backed, so installs and database queries are noticeably faster than the standard HDD option.
- **`--no-address` (no public IP).** The most important setting for security. Without a public IP, the server simply has no address on the internet to attack.
- **Same zone as the subnet.** A server must be in the region its subnet lives in; `us-west1-b` is a zone inside `us-west1`.

### Command (run in Cloud Shell)

```bash
ZONE=us-west1-b

# Create the three servers with identical settings
for VM in vm1-warehouse-db vm2-web vm3-mail; do
  gcloud compute instances create $VM \
    --zone=$ZONE \
    --machine-type=e2-small \
    --image-family=ubuntu-2404-lts-amd64 \
    --image-project=ubuntu-os-cloud \
    --boot-disk-size=20GB \
    --boot-disk-type=pd-balanced \
    --subnet=smallbiz-subnet \
    --no-address \
    --tags=smallbiz
done
```

- The `for` loop runs the same command three times, once per server name, so the servers can't end up with accidentally different settings.
- `--image-family` always picks the newest patched 24.04 image instead of a fixed, older one.
- `--tags=smallbiz` labels the servers so firewall rules can later target just them.

**Check it worked:** run `gcloud compute instances list`. All three show `RUNNING`, an internal IP starting `10.10.0.`, and an empty EXTERNAL\_IP column.

### Connecting to a server

In **Compute Engine → VM instances**, click **SSH** next to a server. Because it has no public IP, the console connects through IAP automatically. From Cloud Shell the equivalent is:

```bash
gcloud compute ssh vm1-warehouse-db --zone=us-west1-b --tunnel-through-iap
```

First step on every server, before installing anything:

```bash
sudo apt update && sudo apt upgrade -y
```

`apt update` downloads the latest list of available packages. `apt upgrade -y` installs all pending security fixes, answering yes automatically. Patching before installing anything means each service starts life on current, secure software.

## 4. VM1: Warehouse database (vm1-warehouse-db)

VM1 runs MariaDB, holding a `warehouse` database with an `inventory` table and a dedicated admin account. It stores the business's internal stock data.

### Why MariaDB

| Database | Strengths | Why not chosen |
| --- | --- | --- |
| **MariaDB** | Free and open source, built into Ubuntu's repositories, fully compatible with MySQL commands, works with phpMyAdmin | **Chosen** |
| MySQL | The original; the same SQL as MariaDB | Would work equally well. MariaDB is community-run and is the default MySQL-family server on many Linux distributions |
| PostgreSQL | Very powerful, strict about data correctness | Different commands and admin tools; phpMyAdmin does not support it, so VM1 and VM2 would need two skill sets |
| Microsoft SQL Server | Industry standard in Windows shops, SSMS GUI | Needs Windows (license cost) or a Linux install with heavier RAM needs |
| SQLite | Zero setup | Not a server: it is a single file used by one application, so it can't serve a warehouse team |

The deciding factor is **consistency**: VM2 also runs MariaDB, so one set of SQL commands, backups and troubleshooting skills covers both databases. If the website later needs warehouse data, the two speak the same language.

### Step 1: Install MariaDB

```bash
sudo apt install -y mariadb-server
systemctl status mariadb
```

- `mariadb-server` installs the database engine and the `mysql`/`mariadb` command-line client.
- Ubuntu starts the service automatically and sets it to start on every boot.
- `systemctl status` should show **active (running)**. Press `q` to leave the status screen.

### Step 2: Secure the installation

A fresh install ships with a test database and anonymous logins meant for experimenting. `mysql_secure_installation` removes them.

```bash
sudo mysql_secure_installation
```

| Prompt | Answer | Why |
| --- | --- | --- |
| Enter current password for root | Press Enter | No password is set yet |
| Switch to unix\_socket authentication | n | Root is already protected: only a Linux user with `sudo` can log in as the database root |
| Change the root password | n | Same reason; no password to steal or guess |
| Remove anonymous users | Y | Anonymous accounts let anyone log in without a name |
| Disallow root login remotely | Y | Root should only ever log in from the server itself |
| Remove test database | Y | The test database is open to all users |
| Reload privilege tables now | Y | Applies the changes immediately |

### Step 3: Create the warehouse database, a table and an admin user

Open the database prompt as root:

```bash
sudo mysql
```

Then run:

```sql
CREATE DATABASE warehouse;
USE warehouse;

CREATE TABLE inventory (
  item_id   INT AUTO_INCREMENT PRIMARY KEY,
  item_name VARCHAR(100) NOT NULL,
  quantity  INT NOT NULL DEFAULT 0,
  location  VARCHAR(50)
);

INSERT INTO inventory (item_name, quantity, location) VALUES
  ('Widget A', 120, 'Aisle 1'),
  ('Widget B', 45,  'Aisle 3'),
  ('Gadget C', 300, 'Aisle 5');

CREATE USER 'warehouse_admin'@'localhost' IDENTIFIED BY 'Choose-A-Strong-Password!';
GRANT ALL PRIVILEGES ON warehouse.* TO 'warehouse_admin'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

What each part does:

- `CREATE DATABASE` makes an empty container for the warehouse's tables. `USE` selects it.
- The `inventory` table has an `item_id` that numbers rows automatically (`AUTO_INCREMENT`) and uniquely identifies each item (`PRIMARY KEY`). `NOT NULL` stops items being saved without a name or quantity.
- The `INSERT` adds sample rows, so the demonstration shows real data coming back.
- `warehouse_admin` is a day-to-day account limited to the `warehouse` database only (`warehouse.*`). Using root for daily work is risky: one mistake could affect every database. This is least privilege again.
- `@'localhost'` means this account can only log in from VM1 itself.

### Step 4: Verify

Log in as the new user (it asks for the password you chose) and query the data:

```bash
mysql -u warehouse_admin -p warehouse
```

```sql
SHOW DATABASES;
SHOW TABLES;
SELECT * FROM inventory;
```

Expected result: `SHOW DATABASES` lists `warehouse` (plus `information_schema`). `SELECT` returns the three sample rows.

**Note on network access.** MariaDB on Ubuntu listens only on 127.0.0.1 (the server itself) by default. That is the safest setting while nothing else needs the database. If a later task connects the website to the warehouse, we will change `bind-address` and create a user for VM2's internal IP.

**Screenshots for submission:** the `SELECT * FROM inventory;` output, and `systemctl status mariadb` showing active (running). Keep the `vm1-warehouse-db` prompt visible in both.

## 5. VM2: Web server (vm2-web)

VM2 runs a LAMP stack: **L**inux, **A**pache, **M**ariaDB and **P**HP, plus phpMyAdmin to manage the web database. Its own MariaDB holds the `webstore` database the website will use in Task 2.

### Why a LAMP stack

| Piece | Chosen | Alternatives considered | Why |
| --- | --- | --- | --- |
| Web server | **Apache** | Nginx, Microsoft IIS | Apache runs PHP directly through `mod_php`, supports per-folder `.htaccess` settings, and phpMyAdmin configures itself for it automatically. Nginx is faster under heavy traffic but needs a separate PHP service (PHP-FPM) and manual setup. IIS requires Windows. |
| Database | **MariaDB** | MySQL, PostgreSQL | Same as VM1, so one skill set covers both servers. phpMyAdmin supports it natively. |
| Language | **PHP** | Node.js, Python | PHP powers a large share of websites (WordPress among them), plugs straight into Apache, and has built-in MariaDB/MySQL support. |
| DB admin tool | **phpMyAdmin** | Command line only, Adminer | A point-and-click web interface for creating tables and browsing data, which makes Task 2 easier. Adminer is lighter but less widely documented. |

The web database lives on the web server itself, as the assignment allows. The website connects over `localhost`, which is faster than a network hop, and the database is never exposed to other machines.

### Step 1: Install and verify Apache

```bash
sudo apt install -y apache2
systemctl status apache2
curl -I http://localhost
```

- `apache2` installs the web server; Ubuntu starts it and enables it on boot.
- `curl -I` requests the page's headers from the server itself. `HTTP/1.1 200 OK` proves Apache is answering.
- Web files live in `/var/www/html`. The default page there is what we show in the screenshot.

### Step 2: Install and secure MariaDB

```bash
sudo apt install -y mariadb-server
sudo mysql_secure_installation
```

Answer the prompts exactly as on VM1 (section 4, step 2): Enter, n, n, then Y to the rest.

### Step 3: Install PHP

```bash
sudo apt install -y php libapache2-mod-php php-mysql
php -v
sudo systemctl restart apache2
```

- `php` is the language itself.
- `libapache2-mod-php` is the module that lets Apache run `.php` files.
- `php-mysql` is the driver PHP uses to talk to MariaDB.
- `php -v` prints the installed version (8.3 on Ubuntu 24.04). Restarting Apache loads the new module.

### Step 4: Install phpMyAdmin

```bash
sudo apt install -y phpmyadmin
```

| Prompt | Answer | Why |
| --- | --- | --- |
| Web server to reconfigure automatically | Press **Space** to mark **apache2** with `*`, then Tab to Ok and Enter | This creates Apache's `/phpmyadmin` address. Skipping it is the most common mistake: the page then returns 404 Not Found |
| Configure database for phpmyadmin with dbconfig-common | Yes | Creates phpMyAdmin's own small settings database for you |
| MySQL application password for phpmyadmin | A strong password | Used internally by phpMyAdmin; you won't type it again |

### Step 5: Create the web database and an admin login

MariaDB's root account uses Linux `sudo` to log in (unix\_socket), so it cannot sign in to phpMyAdmin through a web form. We create a separate login for it.

```bash
sudo mysql
```

```sql
CREATE DATABASE webstore;

CREATE TABLE webstore.products (
  product_id INT AUTO_INCREMENT PRIMARY KEY,
  name       VARCHAR(100) NOT NULL,
  price      DECIMAL(8,2) NOT NULL
);

INSERT INTO webstore.products (name, price) VALUES
  ('Widget A', 19.99),
  ('Gadget C', 49.50);

CREATE USER 'webadmin'@'localhost' IDENTIFIED BY 'Choose-A-Strong-Password!';
GRANT ALL PRIVILEGES ON webstore.* TO 'webadmin'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

- `webstore` is the database the website will use in Task 2; `products` is a starter table so there is data to show.
- `DECIMAL(8,2)` stores money exactly (two decimal places) instead of approximately.
- `webadmin` has full control of `webstore` only, and can only log in from VM2 itself.

### Step 6: View the pages through an IAP tunnel

VM2 has no public IP, so we borrow a secure tunnel through IAP. The easiest way needs no software on your computer:

1. Open **Cloud Shell** and run:

   ```bash
   gcloud compute start-iap-tunnel vm2-web 80 \
     --local-host-port=localhost:8080 --zone=us-west1-b
   ```
2. Leave it running. When it prints `Listening on port [8080]`, click **Web Preview** (the eye-shaped icon on the Cloud Shell toolbar) and choose **Preview on port 8080**.
3. A browser tab opens showing the **Apache2 Default Page**.
4. Add `/phpmyadmin` to the end of that tab's address. Log in as `webadmin` and confirm `webstore` is listed on the left.

The tunnel forwards Cloud Shell's port 8080 to VM2's port 80 over IAP. The traffic is encrypted, and it works only for people signed in to your Google account. It also explains why the `allow-iap` firewall rule opened port 80. Press Ctrl+C in Cloud Shell to close the tunnel.

If you have the gcloud CLI installed on your own computer, the same command works there; then browse to `http://localhost:8080`.

**Screenshots for submission:** the Apache2 Default Page, and phpMyAdmin showing the `webstore` database with the `products` table.

## 6. VM3: Email server (vm3-mail)

VM3 runs Postfix as its mail server, set to deliver mail between accounts on the same machine. Two test accounts, `alice` and `bob`, prove it works by exchanging a message.

### Why Postfix

| Mail server | Strengths | Why not chosen |
| --- | --- | --- |
| **Postfix** | Ubuntu's default mail server, designed with security as a priority, plain-text configuration, huge documentation base | **Chosen** |
| Sendmail | The oldest Unix mail server | Notoriously complex configuration and a long history of security problems |
| Exim | Very flexible; Debian's default | Flexibility means more to configure; fewer Ubuntu-focused guides |
| Microsoft Exchange | Full business email and calendar suite | Needs Windows Server plus licenses and far more RAM than an e2-small |
| Hosted email (Google Workspace, Microsoft 365) | What most real small businesses use | Paid, and the assignment asks us to run our own server |

Postfix is an MTA (mail transfer agent): it accepts messages and delivers them to mailboxes. It does not display mail. For that we add **mailutils**, which provides the `mail` command for sending and reading messages in the terminal.

### Why "Local only"

Google Cloud blocks outgoing traffic on port 25, the port mail servers use to deliver to each other on the internet. Real internet mail would also need a public IP and DNS records, which we deliberately avoid. "Local only" matches what the server can actually do: deliver mail between accounts on this machine, which is exactly what Task 1 asks to demonstrate.

### Step 1: Install Postfix and mailutils

```bash
sudo apt install -y postfix mailutils
```

| Prompt | Answer | Why |
| --- | --- | --- |
| General mail configuration type | **Local only** | Delivers only to users on this server (see above) |
| System mail name | `smallbiz.local` | The domain part of addresses, as in bob@smallbiz.local. `.local` is reserved for private networks, so it can't clash with a real domain |

If you ever need to change these answers: `sudo dpkg-reconfigure postfix`.

### Step 2: Verify Postfix is running

```bash
systemctl status postfix
sudo postfix status
postconf mydestination inet_interfaces
```

- `systemctl status postfix` shows **active (exited)**. That is normal: this unit only launches the real worker (`postfix@-`) and then exits.
- `sudo postfix status` gives the clearer answer: *the Postfix mail system is running*, with its process ID.
- `postconf` prints two key settings. `inet_interfaces = loopback-only` confirms Postfix accepts mail only from the server itself, so it can't be abused by outsiders to send spam. `mydestination` lists the names this server treats as local, including `smallbiz.local`.

### Step 3: Create two mail accounts

```bash
sudo adduser alice
sudo adduser bob
```

Each command asks for a password (type it twice) and optional details such as Full Name, which you can skip with Enter. With Postfix in local mode, every Linux user automatically has a mailbox at `/var/mail/<username>`. No separate email account setup is needed.

### Step 4: Send a message from alice to bob

```bash
sudo su - alice
echo "Hello Bob, this is a Task 1 test from Alice." | mail -s "Task 1 test email" bob
exit
```

- `sudo su - alice` switches to Alice's account, so the message is genuinely sent *from* her.
- `echo "..." |` feeds the message body into the `mail` command; `-s` sets the subject; `bob` is the recipient (short for bob@smallbiz.local).
- `exit` returns to your own account.

### Step 5: Read the message as bob

```bash
sudo su - bob
mail
```

The inbox lists the message from alice. Type `1` and Enter to open it, then `q` to quit. Type `exit` to return to your account.

To show two-way delivery, reply while you are logged in as bob:

```bash
echo "Got it, thanks Alice." | mail -s "Re: Task 1 test email" alice
```

### Step 6: Confirm in the mail log (optional)

```bash
sudo journalctl --no-pager -n 30 | grep postfix
```

Look for lines with `to=<bob@smallbiz.local>` and `status=sent (delivered to mailbox)`. This is the server's own record of the delivery, useful when troubleshooting.

**Screenshots for submission:** `sudo postfix status`, the send command as alice, and bob's inbox showing the message from alice (ideally opened). Keep the `vm3-mail` prompt visible.

## 7. Verification, operations and references

Six screenshots prove the environment is configured and functional. Each needs a one- or two-sentence caption saying what it demonstrates.

### Screenshot checklist

| # | Screenshot | What it demonstrates |
| --- | --- | --- |
| 1 | Compute Engine → VM instances, all three **Running**, External IP column empty | Three servers exist in Google Cloud, running at the same time, with no public exposure |
| 2 | VPC network → `smallbiz-vpc` and its firewall rules | The servers sit on a private network that allows only internal traffic and IAP |
| 3 | VM1: `SELECT * FROM inventory;` and `systemctl status mariadb` | The warehouse SQL database is installed, running and holds data |
| 4 | VM2: Apache2 Default Page in the browser | The web server is installed and serving pages |
| 5 | VM2: phpMyAdmin showing `webstore` and `products` | The web server's SQL database is installed and manageable through phpMyAdmin |
| 6 | VM3: `sudo postfix status` and bob's inbox with alice's message | The email server is running and delivers mail between two local accounts |

Tip: make sure the server name (the SSH window title or the `user@vm-name` prompt) is visible in every terminal screenshot.

### Access and credentials

- **Who can get in:** only Google accounts with access to the project, through IAP. There is no password-based SSH from the internet.
- **Database accounts:** `warehouse_admin` (VM1) and `webadmin` (VM2), each limited to its own database. Database root logins work only through `sudo` on the server itself.
- **Mail accounts:** Linux users `alice` and `bob` on VM3.
- **Passwords** are stored in a password manager, never in this document, in screenshots or in shared chat.

### Routine maintenance

- **Patch weekly** on each server: `sudo apt update && sudo apt upgrade -y`. Reboot if the login message says *System restart required*.
- **Check services** after a reboot: `systemctl status mariadb`, `systemctl status apache2`, `sudo postfix status`.
- **Resize if needed:** stop the server, change its machine type in the console, start it again.

### Cost control

Servers bill for every hour they run, and disks bill even while stopped. Stop all three whenever you finish working:

```bash
gcloud compute instances stop vm1-warehouse-db vm2-web vm3-mail --zone=us-west1-b
```

Start them again with the same command using `start` instead of `stop`. Internal IPs, installed software and data all survive a stop. Use the [Google Cloud Pricing Calculator](https://cloud.google.com/products/calculator) to estimate the monthly cost of three e2-small servers, 20 GB balanced disks and Cloud NAT, and record the figure here.

### Troubleshooting

| Symptom | Likely cause | Fix |
| --- | --- | --- |
| SSH button spins or fails | `allow-iap` rule missing or on the wrong network | Recreate the rule on `smallbiz-vpc` with source 35.235.240.0/20 |
| `apt update` hangs or times out | Cloud NAT missing or in a different region | Create the router and NAT in the subnet's region |
| `/phpmyadmin` returns 404 Not Found | apache2 was not marked with Space during install | `sudo dpkg-reconfigure phpmyadmin` and mark apache2 |
| phpMyAdmin rejects root login | Root uses unix\_socket (sudo) authentication | Log in as `webadmin` instead |
| `mail` shows "No mail for bob" | Message sent to the wrong name, or sent before bob existed | Check the recipient spelling, resend, and check the mail log |

### Sources

- [Use IAP for TCP forwarding](https://docs.cloud.google.com/iap/docs/using-tcp-forwarding) (Google Cloud): the 35.235.240.0/20 IAP range, SSH via IAP, and `start-iap-tunnel`.
- [Sending email from an instance](https://docs.cloud.google.com/compute/docs/tutorials/sending-mail) (Google Cloud): outbound port 25 to destinations outside the VPC is blocked.

Further reading used for package setup: [Ubuntu Server documentation](https://documentation.ubuntu.com/server/), [MariaDB documentation](https://mariadb.com/kb/en/documentation/), [phpMyAdmin documentation](https://docs.phpmyadmin.net/), [Postfix documentation](https://www.postfix.org/documentation.html).
