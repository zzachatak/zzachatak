#!/usr/bin/env bash
# Stop every server to save cloud credit. Data and the reserved IP are kept.
set -euo pipefail
ZONE="${ZONE:-us-west1-b}"
gcloud compute instances stop vm1-warehouse-db vm2-web vm3-mail --zone="$ZONE"
