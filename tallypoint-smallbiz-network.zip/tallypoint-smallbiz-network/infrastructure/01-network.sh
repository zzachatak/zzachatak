#!/usr/bin/env bash
# Task 1: private VPC, subnet, firewall rules and Cloud NAT.
# Run in Google Cloud Shell. Set PROJECT_ID first or rely on your gcloud default.
set -euo pipefail

PROJECT_ID="${PROJECT_ID:-$(gcloud config get-value project)}"
REGION="${REGION:-us-west1}"
gcloud config set project "$PROJECT_ID" >/dev/null

# Custom-mode VPC: nothing is allowed in until we add rules
gcloud compute networks create smallbiz-vpc --subnet-mode=custom

# One /24 subnet with Private Google Access
gcloud compute networks subnets create smallbiz-subnet \
  --network=smallbiz-vpc --region="$REGION" --range=10.10.0.0/24 \
  --enable-private-ip-google-access

# Servers may talk to each other on the private network
gcloud compute firewall-rules create allow-internal \
  --network=smallbiz-vpc --direction=INGRESS --action=ALLOW \
  --rules=all --source-ranges=10.10.0.0/24

# Only Google Identity-Aware Proxy may reach SSH (22) and HTTP (80)
gcloud compute firewall-rules create allow-iap \
  --network=smallbiz-vpc --direction=INGRESS --action=ALLOW \
  --rules=tcp:22,tcp:80 --source-ranges=35.235.240.0/20

# Outbound-only internet access (apt updates) for servers with no public IP
gcloud compute routers create smallbiz-router \
  --network=smallbiz-vpc --region="$REGION"
gcloud compute routers nats create smallbiz-nat \
  --router=smallbiz-router --region="$REGION" \
  --auto-allocate-nat-external-ips --nat-all-subnet-ip-ranges
