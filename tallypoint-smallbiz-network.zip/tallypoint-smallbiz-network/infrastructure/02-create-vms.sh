#!/usr/bin/env bash
# Task 1: three Ubuntu 24.04 LTS servers with internal IPs only.
set -euo pipefail

ZONE="${ZONE:-us-west1-b}"

for VM in vm1-warehouse-db vm2-web vm3-mail; do
  gcloud compute instances create "$VM" \
    --zone="$ZONE" \
    --machine-type=e2-small \
    --image-family=ubuntu-2404-lts-amd64 \
    --image-project=ubuntu-os-cloud \
    --boot-disk-size=20GB \
    --boot-disk-type=pd-balanced \
    --subnet=smallbiz-subnet \
    --no-address \
    --tags=smallbiz
done

gcloud compute instances list
