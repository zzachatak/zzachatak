#!/usr/bin/env bash
# Task 2: make vm2-web a public store, keep vm1-warehouse-db private,
# and block all traffic between the two.
set -euo pipefail

REGION="${REGION:-us-west1}"
ZONE="${ZONE:-us-west1-b}"

# Reserved static IP so WordPress's saved address never changes
gcloud compute addresses create store-ip --region="$REGION"
IP="$(gcloud compute addresses describe store-ip --region="$REGION" --format='value(address)')"
gcloud compute instances add-access-config vm2-web \
  --zone="$ZONE" --access-config-name=external-nat --address="$IP"

# HTTP/HTTPS from anywhere, but only to servers tagged web-server
gcloud compute firewall-rules create allow-web \
  --network=smallbiz-vpc --direction=INGRESS --action=ALLOW \
  --rules=tcp:80,tcp:443 --source-ranges=0.0.0.0/0 --target-tags=web-server

gcloud compute instances add-tags vm2-web --zone="$ZONE" --tags=web-server
gcloud compute instances add-tags vm1-warehouse-db --zone="$ZONE" --tags=warehouse

# Strict separation; priority 900 beats allow-internal (1000)
gcloud compute firewall-rules create deny-web-to-warehouse \
  --network=smallbiz-vpc --direction=INGRESS --action=DENY --rules=all \
  --source-tags=web-server --target-tags=warehouse --priority=900
gcloud compute firewall-rules create deny-warehouse-to-web \
  --network=smallbiz-vpc --direction=INGRESS --action=DENY --rules=all \
  --source-tags=warehouse --target-tags=web-server --priority=900

echo "Store address: http://<static IP shown by: gcloud compute addresses list>"
