"""Draw Tallypoint product images, logo and site icon (original artwork)."""
import sys, math
from PIL import Image, ImageDraw, ImageFont, ImageFilter

OUT = sys.argv[1]
S = 2                      # supersample factor
W = H = 1000
FONT = "/usr/share/fonts/opentype/inter/"
def font(style, size): return ImageFont.truetype(FONT + f"Inter-{style}.otf", int(size * S))

BG     = (242, 239, 232)
INK    = (31, 42, 48)
INK2   = (58, 71, 79)
TEAL   = (14, 90, 98)
TEAL2  = (62, 140, 143)
SCREEN = (214, 236, 234)
AMBER  = (233, 162, 59)
WHITE  = (255, 255, 255)
GRAY   = (201, 205, 208)
GRAY2  = (150, 158, 163)
SHADOW = (222, 217, 207)

def p(*v): return [x * S for x in v]

class Canvas:
    def __init__(self, bg=BG, w=W, h=H):
        self.im = Image.new("RGB", (w * S, h * S), bg)
        self.d = ImageDraw.Draw(self.im)
        self.w, self.h = w, h
    def rr(self, x0, y0, x1, y1, r, fill, outline=None, width=0):
        self.d.rounded_rectangle(p(x0, y0, x1, y1), radius=r * S, fill=fill,
                                 outline=outline, width=int(width * S))
    def rect(self, x0, y0, x1, y1, fill): self.d.rectangle(p(x0, y0, x1, y1), fill=fill)
    def ell(self, x0, y0, x1, y1, fill, outline=None, width=0):
        self.d.ellipse(p(x0, y0, x1, y1), fill=fill, outline=outline, width=int(width * S))
    def poly(self, pts, fill): self.d.polygon([(x * S, y * S) for x, y in pts], fill=fill)
    def line(self, pts, fill, width): self.d.line([(x * S, y * S) for x, y in pts], fill=fill, width=int(width * S), joint="curve")
    def arc(self, box, a0, a1, fill, width): self.d.arc(p(*box), a0, a1, fill=fill, width=int(width * S))
    def text(self, xy, s, f, fill, anchor="la"): self.d.text((xy[0] * S, xy[1] * S), s, font=f, fill=fill, anchor=anchor)
    def save(self, name, size=None):
        out = self.im.resize(size or (self.w, self.h), Image.LANCZOS)
        out.save(f"{OUT}/{name}", optimize=True)

def tally(c, x, y, h, color, stroke):
    """Four upright strokes crossed by a diagonal: the Tallypoint mark."""
    gap = h * 0.22
    for i in range(4):
        c.line([(x + i * gap, y), (x + i * gap, y + h)], color, stroke)
    c.line([(x - gap * 0.45, y + h * 0.82), (x + gap * 3.45, y + h * 0.18)], AMBER, stroke)

def frame(c, label):
    c.ell(220, 800, 780, 860, SHADOW)                       # floor shadow
    tally(c, 64, 922, 34, TEAL, 5)
    c.text((122, 939), "TALLYPOINT", font("Bold", 22), TEAL, "lm")
    c.text((936, 939), label, font("SemiBold", 20), GRAY2, "rm")

def pos_screen(c, x0, y0, x1, y1):
    """A simple point-of-sale screen: item tiles on the left, ticket on the right."""
    c.rr(x0, y0, x1, y1, 10, SCREEN)
    w, h = x1 - x0, y1 - y0
    split = x0 + w * 0.62
    cols, rows = 3, 3
    pad = w * 0.035
    tw = (split - x0 - pad * (cols + 1)) / cols
    th = (h - pad * (rows + 1) - h * 0.12) / rows
    for r in range(rows):
        for k in range(cols):
            tx = x0 + pad + k * (tw + pad)
            ty = y0 + pad + h * 0.12 + r * (th + pad)
            c.rr(tx, ty, tx + tw, ty + th, 8, TEAL2 if (r + k) % 3 else TEAL)
    c.rr(x0 + pad, y0 + pad * 0.8, split - pad, y0 + h * 0.1, 6, WHITE)
    c.rr(split, y0 + pad, x1 - pad, y1 - pad, 8, WHITE)
    for i in range(5):
        ly = y0 + pad * 2 + i * h * 0.1
        c.rr(split + pad, ly, x1 - pad * 2 - w * 0.08, ly + h * 0.035, 4, GRAY)
        c.rr(x1 - pad * 2 - w * 0.06, ly, x1 - pad * 2, ly + h * 0.035, 4, GRAY)
    c.rr(split + pad, y1 - pad * 2 - h * 0.13, x1 - pad * 2, y1 - pad * 2, 8, AMBER)

# ---------- individual illustrations (each draws into the 1000x1000 space) ----------
def terminal(c, ox=0, oy=0, k=1.0):
    def T(x, y): return (ox + x * k, oy + y * k)
    def R(x0, y0, x1, y1): return (*T(x0, y0), *T(x1, y1))
    c.poly([T(430, 610), T(570, 610), T(610, 790), T(390, 790)], INK2)        # stand neck
    c.rr(*R(300, 770, 700, 812), 20 * k, INK)                                # base
    c.rr(*R(170, 170, 830, 640), 34 * k, INK)                                # bezel
    pos_screen(c, *R(205, 205, 795, 605))
    c.ell(*R(492, 616, 508, 632), GRAY2)                                     # status light

def printer(c, ox=0, oy=0, k=1.0):
    def T(x, y): return (ox + x * k, oy + y * k)
    def R(x0, y0, x1, y1): return (*T(x0, y0), *T(x1, y1))
    c.poly([T(395, 150), T(605, 150), T(615, 430), T(385, 430)], WHITE)      # receipt
    for i, wdt in enumerate([150, 120, 160, 90, 140, 110]):
        y = 205 + i * 30
        c.rr(*R(420, y, 420 + wdt, y + 10), 4 * k, GRAY)
    c.rr(*R(420, 385, 580, 400), 4 * k, AMBER)
    c.rr(*R(270, 400, 730, 790), 56 * k, INK)                                # body
    c.rr(*R(300, 390, 700, 470), 24 * k, INK2)                               # cover lip
    c.rr(*R(355, 415, 645, 440), 10 * k, (20, 28, 32))                       # paper slot
    c.rr(*R(310, 700, 690, 760), 18 * k, INK2)                               # front panel
    c.ell(*R(330, 716, 358, 744), TEAL2)
    c.ell(*R(370, 716, 398, 744), AMBER)

def scanner(c, ox=0, oy=0, k=1.0):
    def T(x, y): return (ox + x * k, oy + y * k)
    def R(x0, y0, x1, y1): return (*T(x0, y0), *T(x1, y1))
    # beam towards a barcode label
    c.poly([T(250, 360), T(250, 440), T(120, 540), T(120, 260)], (247, 214, 160))
    c.rr(*R(40, 250, 130, 550), 10 * k, WHITE)
    for i, bw in enumerate([6, 3, 8, 3, 5, 9, 3, 6, 4, 7]):
        x = 54 + sum([6, 3, 8, 3, 5, 9, 3, 6, 4, 7][:i]) * 1.15 + i * 2
        c.rect(*R(x, 270, x + bw, 530), INK)
    # cradle
    c.rr(*R(380, 720, 780, 790), 28 * k, INK2)
    c.poly([T(470, 720), T(690, 720), T(650, 640), T(510, 640)], INK2)
    # handle and head
    c.poly([T(560, 420), T(680, 430), T(620, 720), T(500, 700)], INK)
    c.rr(*R(250, 300, 720, 500), 70 * k, INK)
    c.rr(*R(230, 330, 300, 470), 26 * k, (20, 28, 32))                       # window
    c.rr(*R(420, 470, 470, 540), 14 * k, AMBER)                              # trigger
    c.rr(*R(500, 340, 660, 365), 10 * k, TEAL2)

def drawer(c, ox=0, oy=0, k=1.0):
    def T(x, y): return (ox + x * k, oy + y * k)
    def R(x0, y0, x1, y1): return (*T(x0, y0), *T(x1, y1))
    c.poly([T(150, 420), T(850, 420), T(800, 330), T(200, 330)], INK2)       # top face
    c.rr(*R(150, 410, 850, 610), 18 * k, INK)                                # cabinet
    # open drawer tray
    c.poly([T(190, 600), T(810, 600), T(860, 760), T(140, 760)], (45, 58, 66))
    for i in range(5):
        x0 = 205 + i * 120
        c.poly([T(x0, 610), T(x0 + 105, 610), T(x0 + 112, 690), T(x0 - 7, 690)], (70, 84, 92))
        c.poly([T(x0 + 10, 618), T(x0 + 95, 618), T(x0 + 98, 650), T(x0 + 7, 650)],
               [TEAL2, AMBER, TEAL2, (180, 210, 190), AMBER][i])
    c.rr(*R(140, 700, 860, 790), 14 * k, INK)                                # drawer front
    c.rr(*R(420, 732, 580, 752), 8 * k, (20, 28, 32))                        # handle slot
    c.ell(*R(780, 455, 812, 487), GRAY2)                                     # lock
    c.rr(*R(260, 360, 740, 380), 8 * k, (20, 28, 32))                        # media slot

def card_reader(c, ox=0, oy=0, k=1.0):
    def T(x, y): return (ox + x * k, oy + y * k)
    def R(x0, y0, x1, y1): return (*T(x0, y0), *T(x1, y1))
    for i, r in enumerate([70, 120, 170]):                                    # contactless waves
        c.arc(R(640 - r, 230 - r, 640 + r, 230 + r), 300, 360, TEAL2, 14 * k)
    c.rr(*R(330, 190, 670, 790), 60 * k, INK)                                # body
    c.rr(*R(370, 235, 630, 400), 18 * k, SCREEN)                             # screen
    c.rr(*R(400, 270, 600, 300), 8 * k, TEAL)
    c.rr(*R(400, 320, 540, 345), 8 * k, GRAY)
    c.rr(*R(400, 355, 560, 380), 8 * k, AMBER)
    for r in range(4):
        for q in range(3):
            x = 390 + q * 80; y = 430 + r * 70
            col = WHITE
            if r == 3: col = [(214, 92, 76), AMBER, (88, 160, 110)][q]
            c.rr(*R(x, y, x + 62, y + 50), 12 * k, col if r == 3 else INK2)
    c.rr(*R(410, 735, 590, 755), 8 * k, (20, 28, 32))                        # chip slot
    # card being inserted
    c.rr(*R(420, 690, 580, 760), 10 * k, AMBER)
    c.rr(*R(440, 700, 480, 725), 5 * k, (247, 214, 160))

def software(c, pro=False):
    c.rr(140, 170, 860, 700, 30, INK)                                        # window
    c.rr(140, 170, 860, 230, 30, INK2); c.rect(140, 200, 860, 230, INK2)
    for i, col in enumerate([(214, 92, 76), AMBER, (88, 160, 110)]):
        c.ell(175 + i * 36, 188, 199 + i * 36, 212, col)
    if not pro:
        pos_screen(c, 175, 255, 825, 670)
    else:                                                                     # cloud sync across stores
        c.rr(175, 255, 825, 670, 10, SCREEN)
        cx, cy = 500, 350
        for x0, y0, r in [(cx - 70, cy, 60), (cx + 10, cy - 40, 80), (cx + 90, cy + 5, 55)]:
            c.ell(x0 - r, y0 - r, x0 + r, y0 + r, WHITE)
        c.rr(cx - 130, cy + 5, cx + 145, cy + 60, 28, WHITE)
        for sx in [270, 500, 730]:
            c.line([(cx, cy + 60), (sx, 520)], TEAL2, 6)
            c.poly([(sx - 70, 560), (sx + 70, 560), (sx + 60, 520), (sx - 60, 520)], AMBER)
            c.rr(sx - 60, 560, sx + 60, 640, 6, TEAL)
            c.rr(sx - 18, 590, sx + 18, 640, 4, SCREEN)
    c.rr(380, 700, 620, 730, 0, INK2)                                         # stand
    c.rr(320, 730, 680, 760, 14, INK)
    badge = "PRO" if pro else "ESSENTIALS"
    f = font("Bold", 30)
    bw = c.d.textlength(badge, font=f) / S + 56
    c.rr(840 - bw, 120, 840, 180, 30, AMBER)
    c.text((840 - bw / 2, 150), badge, f, INK, "mm")

def bundle(c):
    drawer(c, 200, 380, 0.6)          # terminal sits on the cash drawer
    terminal(c, 225, 141, 0.55)
    printer(c, -48, 495, 0.45)
    card_reader(c, 608, 534, 0.4)

def service(c):
    # storefront
    c.rr(220, 360, 780, 780, 20, INK)
    for i in range(7):                                                        # awning
        col = AMBER if i % 2 == 0 else WHITE
        c.poly([(220 + i * 80, 300), (300 + i * 80, 300), (300 + i * 80, 380), (220 + i * 80, 380)], col)
        c.ell(220 + i * 80, 345, 300 + i * 80, 415, col)
    c.rr(270, 470, 470, 640, 10, SCREEN)
    c.rr(530, 470, 730, 780, 10, TEAL2)
    c.ell(690, 620, 708, 638, AMBER)
    terminal(c, 278, 500, 0.19)
    # wrench badge
    c.ell(640, 150, 860, 370, TEAL)
    c.line([(700, 315), (800, 215)], WHITE, 26)
    c.ell(772, 182, 830, 240, WHITE)
    c.ell(790, 200, 812, 222, TEAL)
    c.rect(805, 190, 830, 212, TEAL)

PRODUCTS = [
    ("tp-essentials.png", lambda c: software(c, pro=False), "SOFTWARE"),
    ("tp-pro.png",        lambda c: software(c, pro=True),  "SOFTWARE"),
    ("tp-bundle.png",     bundle,                           "POS BUNDLE"),
    ("tp-terminal.png",   terminal,                         "HARDWARE"),
    ("tp-printer.png",    printer,                          "HARDWARE"),
    ("tp-scanner.png",    scanner,                          "HARDWARE"),
    ("tp-drawer.png",     drawer,                           "HARDWARE"),
    ("tp-reader.png",     card_reader,                      "HARDWARE"),
    ("tp-install.png",    service,                          "SERVICES"),
]
for name, fn, label in PRODUCTS:
    c = Canvas()
    if fn is bundle:
        c.ell(70, 815, 930, 875, SHADOW)
    frame(c, label)
    fn(c)
    c.save(name)

# ---------- logo (wordmark) and site icon ----------
c = Canvas(bg=(255, 255, 255), w=600, h=140)
c.im = Image.new("RGBA", (600 * S, 140 * S), (0, 0, 0, 0)); c.d = ImageDraw.Draw(c.im)
c.rr(0, 10, 120, 130, 26, TEAL)
tally(c, 30, 38, 64, WHITE, 9)
c.text((146, 72), "Tallypoint", font("Bold", 62), INK, "lm")
c.text((150, 116), "SYSTEMS", font("SemiBold", 20), TEAL, "lm")
c.save("tp-logo.png")

c = Canvas(bg=TEAL, w=512, h=512)
tally(c, 132, 136, 240, WHITE, 30)
c.save("tp-icon.png")

# ---------- homepage hero ----------
c = Canvas(bg=TEAL, w=1600, h=700)
for i in range(14):
    c.line([(980 + i * 48, 0), (980 + i * 48, 700)], (22, 101, 109), 10)
c.line([(940, 640), (1640, 60)], (196, 136, 50), 14)
terminal(c, 820, 40, 0.72)
printer(c, 1250, 330, 0.4)
c.save("tp-hero.png")
print("ok")
