#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# Tallypoint Systems store setup for vm2-web (Task 2, VM 1: e-commerce server)
#
# What it does:
#   1. Adds the PHP extensions and Apache settings WordPress needs (if missing)
#   2. Installs WP-CLI, the WordPress command-line tool
#   3. Installs and activates WooCommerce and the Storefront theme
#   4. Brands the site as Tallypoint Systems and loads the product catalog,
#      categories, Home and About pages, menu, shipping and test payments
#
# Before running: finish the WordPress web installer at http://<your-ip>.
# Run:            sudo bash tallypoint-store-setup.sh
# Safe to run again: it updates existing products by SKU instead of duplicating.
# ---------------------------------------------------------------------------
set -euo pipefail

WP_PATH=/var/www/html
SELF="$(readlink -f "$0")"

log()  { printf '\n==> %s\n' "$*"; }
fail() { printf '\nERROR: %s\n' "$*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || fail "Run this with sudo:  sudo bash $0"
[ -f "$WP_PATH/wp-config.php" ] || fail "WordPress is not installed yet. Finish the installer at http://<your-static-ip> first, then run this again."

log "Installing PHP extensions and enabling Apache rewrites"
apt-get update -qq
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
  php-curl php-gd php-intl php-mbstring php-soap php-xml php-zip php-imagick unzip curl >/dev/null
if [ ! -f /etc/apache2/conf-available/wordpress.conf ]; then
  printf '<Directory %s>\n    AllowOverride All\n</Directory>\n' "$WP_PATH" > /etc/apache2/conf-available/wordpress.conf
fi
a2enconf -q wordpress >/dev/null
a2enmod -q rewrite >/dev/null
systemctl restart apache2

log "Installing WP-CLI"
if ! command -v wp >/dev/null 2>&1; then
  curl -fsSL -o /usr/local/bin/wp https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar
  chmod +x /usr/local/bin/wp
fi
mkdir -p /tmp/wp-cli-cache && chown www-data:www-data /tmp/wp-cli-cache

# Run from a folder Apache's user can read (your home folder is private to you).
cd "$WP_PATH"
# Run WP-CLI as Apache's user so every file it creates is owned correctly.
wpc() { sudo -u www-data env WP_CLI_CACHE_DIR=/tmp/wp-cli-cache HOME=/tmp wp --path="$WP_PATH" "$@"; }

wpc core is-installed || fail "WordPress files are present but the installer has not been completed. Open http://<your-static-ip> and finish it."
chown -R www-data:www-data "$WP_PATH"

log "Installing WooCommerce and the Storefront theme"
wpc plugin is-installed woocommerce || wpc plugin install woocommerce
wpc plugin is-active woocommerce || wpc plugin activate woocommerce
wpc theme is-installed storefront || wpc theme install storefront
wpc theme activate storefront

ADMIN_ID="$(wpc user list --role=administrator --field=ID --number=1)"
[ -n "$ADMIN_ID" ] || fail "No WordPress administrator account found."

log "Unpacking Tallypoint images"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
chmod 755 "$WORK"
ARCHIVE_LINE=$(awk '/^__TALLYPOINT_ARCHIVE__$/ { print NR + 1; exit }' "$SELF")
tail -n +"$ARCHIVE_LINE" "$SELF" | base64 -d | tar -xzf - -C "$WORK"
chmod -R a+rX "$WORK"

log "Loading the Tallypoint catalog, pages and settings"
wpc eval-file "$WORK/setup.php" "$WORK/img" --user="$ADMIN_ID"

log "Turning on readable links (permalinks)"
wpc rewrite structure '/%postname%/'
if ! grep -q "BEGIN WordPress" "$WP_PATH/.htaccess" 2>/dev/null; then
  cat >> "$WP_PATH/.htaccess" <<'HTACCESS'
# BEGIN WordPress
<IfModule mod_rewrite.c>
RewriteEngine On
RewriteBase /
RewriteRule ^index\.php$ - [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /index.php [L]
</IfModule>
# END WordPress
HTACCESS
  chown www-data:www-data "$WP_PATH/.htaccess"
fi
wpc rewrite flush
wpc cache flush >/dev/null 2>&1 || true

SITE="$(wpc option get home)"
cat <<EOF

------------------------------------------------------------------
 Tallypoint Systems store is ready.

   Store:      $SITE
   Shop:       $SITE/shop/
   About:      $SITE/about/
   Admin:      $SITE/wp-admin/

 Test it in a private/incognito window: register on My Account,
 add the Complete POS Bundle to the cart and check out with
 "Invoice / purchase order (test payment)".
------------------------------------------------------------------
EOF
exit 0
__TALLYPOINT_ARCHIVE__
