<?php
/**
 * Tallypoint Systems store content for WordPress + WooCommerce.
 * Run with: wp eval-file setup.php <image-dir> --user=<admin>
 * Safe to run more than once: products are matched by SKU, pages by slug.
 */

if ( ! class_exists( 'WooCommerce' ) ) {
	WP_CLI::error( 'WooCommerce is not active.' );
}
define( 'TP_IMG', rtrim( isset( $args[0] ) ? $args[0] : '', '/' ) );
if ( ! is_dir( TP_IMG ) ) {
	WP_CLI::error( 'Image folder not found: ' . TP_IMG );
}

require_once ABSPATH . 'wp-admin/includes/image.php';
require_once ABSPATH . 'wp-admin/includes/file.php';
require_once ABSPATH . 'wp-admin/includes/media.php';

/* ------------------------------------------------------------------ helpers */

function tp_image( $file, $title ) {
	$found = get_posts( array(
		'post_type'      => 'attachment',
		'post_status'    => 'inherit',
		'meta_key'       => '_tp_source',
		'meta_value'     => $file,
		'posts_per_page' => 1,
		'fields'         => 'ids',
	) );
	if ( $found ) {
		return (int) $found[0];
	}
	$tmp = wp_tempnam( $file );
	copy( TP_IMG . '/' . $file, $tmp );
	$id = media_handle_sideload( array( 'name' => $file, 'tmp_name' => $tmp ), 0, $title );
	if ( is_wp_error( $id ) ) {
		@unlink( $tmp );
		WP_CLI::warning( "Image $file not imported: " . $id->get_error_message() );
		return 0;
	}
	update_post_meta( $id, '_tp_source', $file );
	update_post_meta( $id, '_wp_attachment_image_alt', $title );
	return (int) $id;
}

function tp_category( $name, $slug, $desc, $image_id ) {
	$term = term_exists( $slug, 'product_cat' );
	if ( ! $term ) {
		$term = wp_insert_term( $name, 'product_cat', array( 'slug' => $slug, 'description' => $desc ) );
	}
	$id = is_array( $term ) ? (int) $term['term_id'] : (int) $term;
	wp_update_term( $id, 'product_cat', array( 'name' => $name, 'description' => $desc ) );
	if ( $image_id ) {
		update_term_meta( $id, 'thumbnail_id', $image_id );
	}
	return $id;
}

function tp_page( $slug, $title, $content, $template = '' ) {
	$page = get_page_by_path( $slug );
	$data = array(
		'post_type'    => 'page',
		'post_status'  => 'publish',
		'post_name'    => $slug,
		'post_title'   => $title,
		'post_content' => $content,
	);
	if ( $page ) {
		$data['ID'] = $page->ID;
		$id = wp_update_post( $data );
	} else {
		$id = wp_insert_post( $data );
	}
	if ( $template ) {
		update_post_meta( $id, '_wp_page_template', $template );
	}
	return (int) $id;
}

/* --------------------------------------------------------- site identity */

WP_CLI::log( 'Setting site identity...' );
update_option( 'blogname', 'Tallypoint Systems' );
update_option( 'blogdescription', 'Windows-native point of sale for independent retailers' );
update_option( 'timezone_string', 'America/Los_Angeles' );

$logo = tp_image( 'tp-logo.png', 'Tallypoint Systems logo' );
$icon = tp_image( 'tp-icon.png', 'Tallypoint site icon' );
$hero = tp_image( 'tp-hero.png', 'Tallypoint terminal and receipt printer' );
if ( $logo ) { set_theme_mod( 'custom_logo', $logo ); }
if ( $icon ) { update_option( 'site_icon', $icon ); }

/* -------------------------------------------------------- store settings */

WP_CLI::log( 'Configuring WooCommerce...' );
WC_Install::create_pages();

$settings = array(
	'woocommerce_currency'                              => 'USD',
	'woocommerce_default_country'                       => 'US',
	'woocommerce_allowed_countries'                     => 'specific',
	'woocommerce_specific_allowed_countries'            => array( 'US' ),
	'woocommerce_ship_to_countries'                     => '',
	'woocommerce_calc_taxes'                            => 'no',
	'woocommerce_manage_stock'                          => 'yes',
	'woocommerce_enable_guest_checkout'                 => 'yes',
	'woocommerce_enable_myaccount_registration'         => 'yes',
	'woocommerce_enable_signup_and_login_from_checkout' => 'yes',
	'woocommerce_registration_generate_username'        => 'yes',
	// Customers choose their own password: this server cannot send email yet.
	'woocommerce_registration_generate_password'        => 'no',
	'woocommerce_coming_soon'                           => 'no',
	'woocommerce_store_pages_only'                      => 'no',
	'woocommerce_onboarding_profile'                    => array( 'skipped' => true ),
);
foreach ( $settings as $key => $value ) {
	update_option( $key, $value );
}

// Offline test payments: no real money changes hands.
update_option( 'woocommerce_cheque_settings', array(
	'enabled'      => 'yes',
	'title'        => 'Invoice / purchase order (test payment)',
	'description'  => 'Place your order now and we will send an invoice. No card is charged.',
	'instructions' => 'Thank you for your order. An invoice will follow from Tallypoint accounts receivable.',
) );
update_option( 'woocommerce_cod_settings', array(
	'enabled'            => 'yes',
	'title'              => 'Pay on delivery (test payment)',
	'description'        => 'Pay when your equipment is delivered or installed.',
	'instructions'       => 'Payment is collected on delivery or at installation.',
	'enable_for_methods' => array(),
	'enable_for_virtual' => 'yes',
) );

// Shipping: one zone for the United States.
$zone = null;
foreach ( WC_Shipping_Zones::get_zones() as $z ) {
	if ( 'United States' === $z['zone_name'] ) {
		$zone = new WC_Shipping_Zone( $z['id'] );
	}
}
if ( ! $zone ) {
	$zone = new WC_Shipping_Zone();
	$zone->set_zone_name( 'United States' );
	$zone->set_zone_order( 0 );
	$zone->add_location( 'US', 'country' );
	$zone->save();
	$flat = $zone->add_shipping_method( 'flat_rate' );
	update_option( "woocommerce_flat_rate_{$flat}_settings", array(
		'title'      => 'Ground shipping (UPS / FedEx)',
		'tax_status' => 'none',
		'cost'       => '25',
	) );
	$free = $zone->add_shipping_method( 'free_shipping' );
	update_option( "woocommerce_free_shipping_{$free}_settings", array(
		'title'            => 'Free ground shipping on orders over $1,000',
		'requires'         => 'min_amount',
		'min_amount'       => '1000',
		'ignore_discounts' => 'no',
	) );
}

/* ------------------------------------------------------------ categories */

WP_CLI::log( 'Creating categories...' );
$img = array();
foreach ( array(
	'essentials' => array( 'tp-essentials.png', 'Tallypoint POS Essentials on a Windows screen' ),
	'pro'        => array( 'tp-pro.png', 'Tallypoint POS Pro syncing inventory across stores' ),
	'bundle'     => array( 'tp-bundle.png', 'Tallypoint Complete POS Bundle' ),
	'terminal'   => array( 'tp-terminal.png', 'Tallypoint 15-inch touchscreen terminal' ),
	'printer'    => array( 'tp-printer.png', 'Thermal receipt printer' ),
	'scanner'    => array( 'tp-scanner.png', '2D barcode scanner with stand' ),
	'drawer'     => array( 'tp-drawer.png', 'Cash drawer' ),
	'reader'     => array( 'tp-reader.png', 'EMV and contactless card reader' ),
	'install'    => array( 'tp-install.png', 'On-site installation and training' ),
) as $key => $item ) {
	$img[ $key ] = tp_image( $item[0], $item[1] );
}

$cat = array(
	'software' => tp_category( 'Software', 'software', 'Tallypoint POS app licenses for Windows terminals.', $img['pro'] ),
	'bundles'  => tp_category( 'POS Bundles', 'pos-bundles', 'Complete checkout stations, imaged and tested before they ship.', $img['bundle'] ),
	'hardware' => tp_category( 'Hardware', 'hardware', 'Terminals and peripherals certified for Tallypoint.', $img['terminal'] ),
	'services' => tp_category( 'Services', 'services', 'Installation, data migration and staff training.', $img['install'] ),
);

/* -------------------------------------------------------------- products */

$products = array(
	array(
		'sku'      => 'TP-SW-ESS',
		'name'     => 'Tallypoint POS Essentials – 1-Month License',
		'price'    => '69.00',
		'cat'      => 'software',
		'img'      => 'essentials',
		'virtual'  => true,
		'featured' => true,
		'short'    => 'The Windows-native Tallypoint POS app for one terminal: ring up sales, take payments and track inventory.',
		'desc'     => <<<'HTML'
<p>Tallypoint POS Essentials is the point-of-sale app built for Windows. It runs on the touchscreen terminal you already have and keeps your counter moving, even when the internet does not.</p>
<ul>
<li>Fast checkout with barcode scanning, discounts, returns and split payments</li>
<li>Integrated card payments with tokenization, so card numbers are never stored on the terminal</li>
<li>Offline mode: keep selling during an outage and sync automatically when the connection returns</li>
<li>Works with many existing receipt printers, barcode scanners and cash drawers</li>
<li>Inventory counts and daily sales reports for your store</li>
</ul>
<p><strong>License:</strong> one terminal for one month. Order again to renew.</p>
HTML
	),
	array(
		'sku'      => 'TP-SW-PRO',
		'name'     => 'Tallypoint POS Pro – 1-Month License',
		'price'    => '129.00',
		'cat'      => 'software',
		'img'      => 'pro',
		'virtual'  => true,
		'featured' => true,
		'short'    => 'Everything in Essentials, plus cloud inventory sync for chains of up to 50 locations.',
		'desc'     => <<<'HTML'
<p>Tallypoint POS Pro connects every store in your chain. Each terminal keeps working on its own, and the cloud keeps inventory, prices and sales in step across locations.</p>
<ul>
<li>Everything included in POS Essentials</li>
<li>Cloud inventory sync across up to 50 store locations</li>
<li>One product catalog and price list managed from head office</li>
<li>Chain-wide sales and stock reporting</li>
<li>Priority phone and chat support</li>
</ul>
<p><strong>License:</strong> one terminal for one month. Order one license per terminal.</p>
HTML
	),
	array(
		'sku'      => 'TP-BND-CMP',
		'name'     => 'Tallypoint Complete POS Bundle',
		'price'    => '1899.00',
		'cat'      => 'bundles',
		'img'      => 'bundle',
		'stock'    => 22,
		'weight'   => '38',
		'featured' => true,
		'short'    => 'A full checkout counter in one box: touchscreen, printer, scanner, cash drawer and card reader, with Tallypoint preinstalled.',
		'desc'     => <<<'HTML'
<p>The Complete POS Bundle is everything a checkout counter needs. Our fulfillment team assembles every bundle, images the terminal with Tallypoint and tests each device together before it ships, so you can plug it in and start selling.</p>
<h3>In the box</h3>
<ul>
<li>15-inch touchscreen terminal running Windows IoT Enterprise, with Tallypoint POS preinstalled</li>
<li>Thermal receipt printer</li>
<li>2D barcode scanner with stand</li>
<li>Heavy-duty cash drawer</li>
<li>EMV chip and contactless card reader</li>
<li>All cables, plus the first month of POS Essentials</li>
</ul>
<p>Add <em>On-Site Installation &amp; Training</em> and a Tallypoint installer will set it up for you.</p>
HTML
	),
	array(
		'sku'      => 'TP-HW-TRM',
		'name'     => 'Tallypoint 15" Touchscreen Terminal',
		'price'    => '1099.00',
		'cat'      => 'hardware',
		'img'      => 'terminal',
		'stock'    => 30,
		'weight'   => '14',
		'short'    => 'A spill-resistant 15-inch touchscreen terminal, imaged with Windows IoT Enterprise and Tallypoint POS.',
		'desc'     => <<<'HTML'
<p>Add a checkout lane or replace an aging register. The terminal arrives imaged with Windows IoT Enterprise and Tallypoint POS, ready to sign in.</p>
<ul>
<li>15-inch projected-capacitive touchscreen on a tilting stand</li>
<li>USB and Ethernet ports for printers, scanners, cash drawers and card readers</li>
<li>Windows IoT Enterprise for long-term support and locked-down kiosk use</li>
</ul>
HTML
	),
	array(
		'sku'      => 'TP-HW-PRN',
		'name'     => 'Thermal Receipt Printer',
		'price'    => '329.00',
		'cat'      => 'hardware',
		'img'      => 'printer',
		'stock'    => 60,
		'weight'   => '5',
		'short'    => 'Fast 80 mm thermal receipt printer with auto-cutter. Opens the cash drawer on every sale.',
		'desc'     => <<<'HTML'
<p>Quiet, fast receipts with no ink to replace. Tallypoint prints receipts, gift receipts and end-of-day reports, and triggers the cash drawer through the printer.</p>
<ul>
<li>80 mm thermal paper with automatic cutter</li>
<li>USB and Ethernet connections</li>
<li>Cash drawer kick port</li>
</ul>
HTML
	),
	array(
		'sku'      => 'TP-HW-SCN',
		'name'     => '2D Barcode Scanner with Stand',
		'price'    => '189.00',
		'sale'     => '169.00',
		'cat'      => 'hardware',
		'img'      => 'scanner',
		'stock'    => 75,
		'weight'   => '1',
		'short'    => 'Reads 1D and 2D barcodes, including codes on phone screens. Works handheld or hands-free in its stand.',
		'desc'     => <<<'HTML'
<p>Scan product labels, loyalty cards and mobile coupons in one pass. Lift it out of the stand for bulky items on the counter.</p>
<ul>
<li>Reads 1D barcodes and 2D codes such as QR</li>
<li>Reads codes from phone screens</li>
<li>Plug-and-play USB with Tallypoint</li>
</ul>
HTML
	),
	array(
		'sku'      => 'TP-HW-DRW',
		'name'     => 'Heavy-Duty Cash Drawer',
		'price'    => '159.00',
		'cat'      => 'hardware',
		'img'      => 'drawer',
		'stock'    => 40,
		'weight'   => '18',
		'short'    => 'Steel cash drawer with five bill and five coin slots. Opens automatically when a sale completes.',
		'desc'     => <<<'HTML'
<p>A sturdy steel drawer that sits under the terminal. Tallypoint opens it through the receipt printer only when a cash sale or payout is recorded, so every opening is logged.</p>
<ul>
<li>5 bill slots and 5 coin cups, removable till</li>
<li>Media slot for checks and receipts</li>
<li>Three-position key lock</li>
</ul>
HTML
	),
	array(
		'sku'      => 'TP-HW-CRD',
		'name'     => 'EMV & Contactless Card Reader',
		'price'    => '279.00',
		'cat'      => 'hardware',
		'img'      => 'reader',
		'stock'    => 15,
		'weight'   => '1',
		'featured' => true,
		'short'    => 'Chip, tap and mobile wallet payments with a built-in PIN pad, integrated with Tallypoint payments.',
		'desc'     => <<<'HTML'
<p>Take every common card payment at the counter. The reader connects to Tallypoint's integrated payments, and card data is tokenized so it never touches your terminal.</p>
<ul>
<li>EMV chip, contactless tap and mobile wallets</li>
<li>Built-in PIN pad and color display</li>
<li>Designed for PCI DSS compliant payment flows</li>
</ul>
HTML
	),
	array(
		'sku'      => 'TP-SVC-INS',
		'name'     => 'On-Site Installation & Training',
		'price'    => '499.00',
		'cat'      => 'services',
		'img'      => 'install',
		'virtual'  => true,
		'featured' => true,
		'short'    => 'A Tallypoint installer sets up your terminals, moves your data from your old POS and trains your staff.',
		'desc'     => <<<'HTML'
<p>Our installation team comes to your store so you are selling on Tallypoint the same day.</p>
<ul>
<li>Hardware setup for up to four checkout lanes</li>
<li>Product, customer and stock data migrated from your previous POS system</li>
<li>Hands-on training for managers and cashiers</li>
<li>Follow-up visit for repairs or adjustments if needed</li>
</ul>
<p>Priced per store location. Our team will contact you to schedule after you order.</p>
HTML
	),
);

WP_CLI::log( 'Creating products...' );
foreach ( $products as $d ) {
	$id      = wc_get_product_id_by_sku( $d['sku'] );
	$product = $id ? wc_get_product( $id ) : new WC_Product_Simple();
	$product->set_name( $d['name'] );
	$product->set_sku( $d['sku'] );
	$product->set_regular_price( $d['price'] );
	$product->set_sale_price( isset( $d['sale'] ) ? $d['sale'] : '' );
	$product->set_short_description( $d['short'] );
	$product->set_description( trim( $d['desc'] ) );
	$product->set_category_ids( array( $cat[ $d['cat'] ] ) );
	$product->set_image_id( $img[ $d['img'] ] );
	$product->set_featured( ! empty( $d['featured'] ) );
	$product->set_virtual( ! empty( $d['virtual'] ) );
	$product->set_catalog_visibility( 'visible' );
	$product->set_status( 'publish' );
	if ( isset( $d['stock'] ) ) {
		$product->set_manage_stock( true );
		$product->set_stock_quantity( $d['stock'] );
	} else {
		$product->set_manage_stock( false );
		$product->set_stock_status( 'instock' );
	}
	if ( isset( $d['weight'] ) ) {
		$product->set_weight( $d['weight'] );
	}
	$saved = $product->save();
	WP_CLI::log( sprintf( '  %-11s %-46s $%s', $d['sku'], $d['name'], isset( $d['sale'] ) ? $d['sale'] : $d['price'] ) );
}

/* ----------------------------------------------------------------- pages */

WP_CLI::log( 'Creating pages and menu...' );

$bundles_url  = get_term_link( $cat['bundles'], 'product_cat' );
$software_url = get_term_link( $cat['software'], 'product_cat' );

$home_content = '<p>Windows-native POS software and ready-to-run checkout hardware for independent retailers and small chains. Keep selling through an internet outage, and keep every store in sync when you are back online.</p>'
	. '<p><a class="button alt" href="' . esc_url( $bundles_url ) . '">Shop POS bundles</a> &nbsp; '
	. '<a class="button" href="' . esc_url( $software_url ) . '">Compare software plans</a></p>';
$home = tp_page( 'home', 'Point of sale that keeps selling, even offline', $home_content, 'template-homepage.php' );
if ( $hero ) {
	set_post_thumbnail( $home, $hero );
}

$about_content = <<<'HTML'
<p><strong>Tallypoint Systems builds point-of-sale software and hardware for Windows.</strong> Independent retailers and small chains with 1 to 50 locations use Tallypoint to ring up sales, take payments and track inventory. Our customers include boutiques, hardware stores, pet stores and liquor stores.</p>

<h2>What we make</h2>
<ul>
<li><strong>Tallypoint POS</strong>, a monthly subscription app for Windows terminals, with integrated card payments and cloud inventory that syncs across stores.</li>
<li><strong>Complete POS bundles</strong>: touchscreen terminal, receipt printer, barcode scanner, cash drawer and card reader. Our fulfillment team assembles every bundle, images the terminal and tests it before it ships.</li>
</ul>

<h2>Why retailers choose Tallypoint</h2>
<ul>
<li><strong>Windows-native.</strong> Runs on the Windows hardware many stores already own, instead of requiring tablets.</li>
<li><strong>Works offline.</strong> Checkout keeps running during an internet outage and syncs to the cloud when the connection returns.</li>
<li><strong>Supports older peripherals.</strong> Keep the printers and scanners you already have.</li>
</ul>

<h2>Security comes first</h2>
<p>Every swipe, tap and chip payment passes through a Tallypoint terminal, so security sits in our leadership team. Our dedicated Security &amp; Compliance group maintains PCI DSS compliance and works with independent penetration testers. Card data is tokenized, and every software update is code-signed before it reaches a store.</p>

<h2>Installation and support</h2>
<p>Our installation team sets up new stores on site, migrates data from previous POS systems, trains staff and handles repairs. Our support team helps by phone and chat with both the app and hardware replacements.</p>

<h2>Our team</h2>
<p>Tallypoint is a team of 136 people across software and hardware engineering, security, fulfillment, installation, support and sales. We also work with payment-processing partners and resellers who sell and install Tallypoint.</p>
HTML;
$about = tp_page( 'about', 'About Tallypoint', $about_content );

update_option( 'show_on_front', 'page' );
update_option( 'page_on_front', $home );

// Tidy the WordPress sample content.
foreach ( array( 'sample-page' => 'page', 'hello-world' => 'post' ) as $slug => $type ) {
	$old = get_page_by_path( $slug, OBJECT, $type );
	if ( $old && 'trash' !== $old->post_status ) {
		wp_trash_post( $old->ID );
	}
}

// Main menu.
$menu_name = 'Tallypoint Main Menu';
$existing  = wp_get_nav_menu_object( $menu_name );
if ( $existing ) {
	wp_delete_nav_menu( $existing->term_id );
}
$menu = wp_create_nav_menu( $menu_name );
$pos  = 1;
$add_page = function ( $page_id, $title ) use ( $menu, &$pos ) {
	wp_update_nav_menu_item( $menu, 0, array(
		'menu-item-title'     => $title,
		'menu-item-object'    => 'page',
		'menu-item-object-id' => $page_id,
		'menu-item-type'      => 'post_type',
		'menu-item-status'    => 'publish',
		'menu-item-position'  => $pos++,
	) );
};
$add_cat = function ( $term_id, $title ) use ( $menu, &$pos ) {
	wp_update_nav_menu_item( $menu, 0, array(
		'menu-item-title'     => $title,
		'menu-item-object'    => 'product_cat',
		'menu-item-object-id' => $term_id,
		'menu-item-type'      => 'taxonomy',
		'menu-item-status'    => 'publish',
		'menu-item-position'  => $pos++,
	) );
};
$add_page( $home, 'Home' );
$add_page( wc_get_page_id( 'shop' ), 'Shop' );
$add_cat( $cat['bundles'], 'POS Bundles' );
$add_cat( $cat['software'], 'Software' );
$add_cat( $cat['hardware'], 'Hardware' );
$add_cat( $cat['services'], 'Services' );
$add_page( $about, 'About' );
$add_page( wc_get_page_id( 'myaccount' ), 'My Account' );
set_theme_mod( 'nav_menu_locations', array( 'primary' => $menu, 'handheld' => $menu ) );

/* ------------------------------------------------------------ appearance */

WP_CLI::log( 'Applying Tallypoint colors...' );
$mods = array(
	'storefront_heading_color'              => '#1f2a30',
	'storefront_text_color'                 => '#3a474f',
	'storefront_accent_color'               => '#0e5a62',
	'storefront_header_background_color'    => '#ffffff',
	'storefront_header_text_color'          => '#3a474f',
	'storefront_header_link_color'          => '#0e5a62',
	'storefront_button_background_color'    => '#0e5a62',
	'storefront_button_text_color'          => '#ffffff',
	'storefront_button_alt_background_color' => '#e9a23b',
	'storefront_button_alt_text_color'      => '#1f2a30',
	'storefront_footer_background_color'    => '#1f2a30',
	'storefront_footer_heading_color'       => '#ffffff',
	'storefront_footer_text_color'          => '#c9cdd0',
	'storefront_footer_link_color'          => '#ffffff',
	'storefront_hero_heading_color'         => '#ffffff',
	'storefront_hero_text_color'            => '#ffffff',
);
foreach ( $mods as $key => $value ) {
	set_theme_mod( $key, $value );
}

$css = <<<'CSS'
/* Tallypoint homepage hero */
.page-template-template-homepage .type-page.has-post-thumbnail {
	background-color: #0e5a62;
	background-size: cover;
	background-position: right center;
	padding-top: 5em;
	padding-bottom: 5em;
}
.page-template-template-homepage .type-page.has-post-thumbnail .entry-title,
.page-template-template-homepage .type-page.has-post-thumbnail .entry-content,
.page-template-template-homepage .type-page.has-post-thumbnail .entry-content p {
	color: #ffffff;
	max-width: 30em;
	text-align: left;
}
.page-template-template-homepage .type-page.has-post-thumbnail .entry-header,
.page-template-template-homepage .type-page.has-post-thumbnail .entry-content {
	margin-left: 0;
}
.site-header .custom-logo-link img { max-width: 240px; height: auto; }
.woocommerce-products-header__title, .storefront-product-section .section-title { color: #1f2a30; }
CSS;
wp_update_custom_css_post( $css, array( 'stylesheet' => get_stylesheet() ) );

flush_rewrite_rules( true );
WP_CLI::success( 'Tallypoint store content is in place.' );
