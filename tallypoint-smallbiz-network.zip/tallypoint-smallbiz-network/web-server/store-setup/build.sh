#!/usr/bin/env bash
# Packages header.sh + setup.php + images/ into one self-contained installer:
#   dist/tallypoint-store-setup.sh
# Upload that file to the web server and run: sudo bash tallypoint-store-setup.sh
set -euo pipefail
cd "$(dirname "$0")"

STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT
mkdir -p "$STAGE/img" dist
cp setup.php "$STAGE/"
cp images/*.png "$STAGE/img/"

{
  cat header.sh
  tar -C "$STAGE" -czf - setup.php img | base64 -w 76
} > dist/tallypoint-store-setup.sh
chmod +x dist/tallypoint-store-setup.sh
bash -n dist/tallypoint-store-setup.sh
echo "Built dist/tallypoint-store-setup.sh ($(du -h dist/tallypoint-store-setup.sh | cut -f1))"
